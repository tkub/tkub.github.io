# /// script
# requires-python = ">=3.12"
# dependencies = ["marimo>=0.24", "polars>=1.0", "numpy>=2.0", "scipy>=1.14", "scikit-learn>=1.5", "plotly>=5.24", "regex>=2024.9"]
# ///

import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _():
    import marimo as mo
    import numpy as np
    import polars as pl
    import plotly.graph_objects as go
    from sklearn.preprocessing import StandardScaler

    return StandardScaler, go, mo, np, pl


@app.cell(hide_code=True)
def _(mo, np, pl):
    df = pl.read_csv(str(mo.notebook_location() / "public" / "features.csv"))
    cols = [c for c in df.columns if c not in ("著者", "題名", "区分")]
    X = df.select(cols).to_numpy()
    y = df["著者"].to_numpy()
    titles = df["題名"].to_list()
    groups = np.array([a + ":" + t.split("_")[0] for a, t in zip(y, titles)])
    colors = dict(
        zip(
            sorted(set(y)),
            [
                "#0072B2",
                "#D55E00",
                "#009E73",
                "#CC79A7",
                "#E69F00",
                "#56B4E9",
                "#332288",
                "#882255",
            ],
        )
    )
    return X, colors, groups, titles, y


@app.cell(hide_code=True)
def _(mo):
    mo.md("""
    # どこで答えが漏れたか
    第9章の授業用。実データのラベルに、無関係な乱数の列を対応させる。
    **列を選ぶ場所を変えただけで、成績はどれだけ変わるか。**
    比較する手順は、使う乱数、分割、選ぶ列数、標準化、分類器をそろえる。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    noise_columns = mo.ui.slider(
        steps=[50, 200, 500, 1000, 2000], value=500, label="乱数の列数", show_value=True
    )
    selected_count = mo.ui.slider(1, 30, value=10, label="選ぶ列数", show_value=True)
    experiment_seed = mo.ui.slider(0, 19, value=0, label="乱数と分割の番号", show_value=True)
    mo.hstack(
        [noise_columns, selected_count, experiment_seed],
        wrap=True,
        justify="start",
        gap=2,
    )
    return experiment_seed, noise_columns, selected_count


@app.cell(hide_code=True)
def _(StandardScaler, experiment_seed, noise_columns, np, selected_count, y):
    from sklearn.feature_selection import SelectKBest, f_classif
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.model_selection import StratifiedKFold, StratifiedGroupKFold
    from sklearn.dummy import DummyClassifier

    splits = list(
        StratifiedKFold(5, shuffle=True, random_state=experiment_seed.value).split(
            np.zeros(len(y)), y
        )
    )
    noise = np.random.default_rng(experiment_seed.value).normal(size=(len(y), noise_columns.value))
    # 漏洩ありは、列を選ぶ処理だけが分割の外にある。
    selected_all = SelectKBest(f_classif, k=selected_count.value).fit_transform(noise, y)
    noise_scores = []
    for _train, _test in splits:
        _bad = make_pipeline(StandardScaler(), KNeighborsClassifier(5)).fit(
            selected_all[_train], y[_train]
        )
        _good = make_pipeline(
            SelectKBest(f_classif, k=selected_count.value),
            StandardScaler(),
            KNeighborsClassifier(5),
        ).fit(noise[_train], y[_train])
        _dummy = DummyClassifier(strategy="most_frequent").fit(noise[_train], y[_train])
        noise_scores.append(
            [
                _bad.score(selected_all[_test], y[_test]),
                _good.score(noise[_test], y[_test]),
                _dummy.score(noise[_test], y[_test]),
            ]
        )
    noise_scores = np.array(noise_scores)
    return (
        KNeighborsClassifier,
        StratifiedGroupKFold,
        make_pipeline,
        noise_scores,
        splits,
    )


@app.cell(hide_code=True)
def _(go, mo, noise_scores, np):
    noise_fig = go.Figure()
    for _i, _name in enumerate(
        ["全作品で列を選ぶ", "訓練作品だけで列を選ぶ", "訓練側の最頻クラス"]
    ):
        noise_fig.add_trace(
            go.Scatter(
                x=list(range(1, 6)),
                y=noise_scores[:, _i],
                mode="lines+markers",
                name=_name,
            )
        )
    noise_fig.update_layout(
        height=340,
        template="plotly_white",
        xaxis=dict(title="フォールド", dtick=1),
        yaxis=dict(title="検証正解率", range=[0, 1]),
        legend=dict(orientation="h", y=1.15),
        margin=dict(t=50, b=40),
    )
    mo.vstack(
        [
            noise_fig,
            mo.md(
                f"平均正解率: 全作品で選択 **{noise_scores[:, 0].mean():.3f}** / 訓練だけで選択 **{noise_scores[:, 1].mean():.3f}** / 最頻クラス **{noise_scores[:, 2].mean():.3f}**。差は **{np.mean(noise_scores[:, 0] - noise_scores[:, 1]):+.3f}**。\n\n列数を増やして比較する。乱数の番号も変え、1回の結果で判断しない。最頻クラスの値は比較用の基準であり、正解率の下限ではない。"
            ),
        ]
    )
    return


@app.cell(hide_code=True)
def _(
    KNeighborsClassifier,
    StandardScaler,
    X,
    go,
    make_pipeline,
    mo,
    np,
    splits,
    y,
):
    _whole = StandardScaler().fit_transform(X)
    pre_scores = []
    for _train, _test in splits:
        _bad = KNeighborsClassifier(5).fit(_whole[_train], y[_train])
        _good = make_pipeline(StandardScaler(), KNeighborsClassifier(5)).fit(X[_train], y[_train])
        pre_scores.append([_bad.score(_whole[_test], y[_test]), _good.score(X[_test], y[_test])])
    pre_scores = np.array(pre_scores)
    pre_fig = go.Figure(
        go.Bar(
            x=list(range(1, 6)),
            y=pre_scores[:, 0] - pre_scores[:, 1],
            marker_color="#0072B2",
        )
    )
    pre_fig.add_hline(y=0, line_color="#333")
    pre_fig.update_layout(
        height=260,
        template="plotly_white",
        xaxis=dict(title="フォールド", dtick=1),
        yaxis_title="分割前に標準化した成績 − 訓練側だけで標準化した成績",
        margin=dict(t=20, b=40),
    )
    mo.vstack(
        [
            mo.md(
                f"## 標準化だけを外に出すと\n同じ分割を使い、実データの52列で著者を分類する。二つの手順による平均正解率の差は **{np.mean(pre_scores[:, 0] - pre_scores[:, 1]):+.3f}**。差が負になる分割もありうる。正解率が上がらなくても、検証データを使って標準化の平均と標準偏差を計算したことには変わりがない。"
            ),
            pre_fig,
        ]
    )
    return


@app.cell(hide_code=True)
def _(mo):
    _lead = mo.md("""
    ## テスト側のばらつきで、近い点が入れ替わる
    **人工データで標準化の影響だけを取り出す。** 横軸はクラスを分ける測定値、
    縦軸は測定環境に左右される値とする。訓練側では両方がクラスと関係するが、
    テスト側では縦軸の関係が逆転する。さらに縦軸の振れ幅を大きくしてみる。

    両手順には同じ訓練40点とテスト40点を渡す。違いは、尺度を求めるときにテスト40点を含めるかだけ。
    テストの正解ラベルは、どちらの学習にも渡さない。
    """)
    shift_size = mo.ui.slider(
        0, 20, step=0.5, value=10, label="テスト側の縦軸の振れ幅", show_value=True
    )
    scaling_kind = mo.ui.dropdown(
        ["標準化（標準偏差）", "Min-Max（範囲）"],
        value="標準化（標準偏差）",
        label="尺度の求め方",
    )
    scaling_k = mo.ui.slider(1, 9, step=2, value=5, label="k", show_value=True)
    scaling_focus = mo.ui.slider(0, 39, value=0, label="線を引くテスト点", show_value=True)
    scaling_view = mo.ui.switch(value=False, label="変換後の座標で表示")
    mo.vstack(
        [
            _lead,
            mo.hstack(
                [shift_size, scaling_kind, scaling_k, scaling_focus, scaling_view],
                wrap=True,
                justify="start",
                gap=2,
            ),
        ]
    )
    return scaling_focus, scaling_k, scaling_kind, scaling_view, shift_size


@app.cell(hide_code=True)
def _(np, shift_size):
    _rng = np.random.default_rng(42)
    scaling_labels = np.repeat([0, 1], 20)
    _sign = 2 * scaling_labels - 1
    scaling_train = np.column_stack(
        [_sign + _rng.normal(0, 0.12, 40), -_sign + _rng.normal(0, 0.15, 40)]
    )
    scaling_test = np.column_stack(
        [
            _sign + _rng.normal(0, 0.12, 40),
            shift_size.value * (_sign + _rng.normal(0, 0.15, 40)),
        ]
    )
    return scaling_labels, scaling_test, scaling_train


@app.cell(hide_code=True)
def _(
    KNeighborsClassifier,
    StandardScaler,
    np,
    scaling_k,
    scaling_kind,
    scaling_labels,
    scaling_test,
    scaling_train,
):
    from sklearn.preprocessing import MinMaxScaler

    _factory = StandardScaler if scaling_kind.value == "標準化（標準偏差）" else MinMaxScaler
    scaling_results = []
    for _name, _fit in [
        ("訓練だけで尺度を求める", scaling_train),
        ("訓練＋テストで尺度を求める", np.vstack([scaling_train, scaling_test])),
    ]:
        _scaler = _factory().fit(_fit)
        _tr = _scaler.transform(scaling_train)
        _te = _scaler.transform(scaling_test)
        _model = KNeighborsClassifier(scaling_k.value).fit(_tr, scaling_labels)
        _pred = _model.predict(_te)
        _dist, _idx = _model.kneighbors(_te)
        _divisor = _scaler.scale_ if isinstance(_scaler, StandardScaler) else 1 / _scaler.scale_
        scaling_results.append(
            dict(
                name=_name,
                train=_tr,
                test=_te,
                pred=_pred,
                accuracy=float(np.mean(_pred == scaling_labels)),
                distances=_dist,
                indices=_idx,
                divisor=_divisor,
                scaler=_scaler,
            )
        )
    return (scaling_results,)


@app.cell(hide_code=True)
def _(
    go,
    mo,
    np,
    scaling_focus,
    scaling_k,
    scaling_labels,
    scaling_results,
    scaling_test,
    scaling_train,
    scaling_view,
):
    from plotly.subplots import make_subplots

    _focus = scaling_focus.value
    scaling_fig = make_subplots(
        rows=1,
        cols=2,
        subplot_titles=[r["name"] for r in scaling_results],
        horizontal_spacing=0.12,
    )
    _palette = np.array(["#0072B2", "#D55E00"])
    _rows = []
    _all_points = np.vstack([scaling_train, scaling_test])
    _low = _all_points.min(axis=0)
    _high = _all_points.max(axis=0)
    _pad = 0.12 * np.maximum(_high - _low, 1)
    for _panel, _r in enumerate(scaling_results, 1):
        _tr = _r["train"] if scaling_view.value else scaling_train
        _te = _r["test"] if scaling_view.value else scaling_test
        _near = _r["indices"][_focus]
        # 元の座標では左右で点の位置と軸の範囲をそろえる。
        _bounds = np.vstack([_low - _pad, _high + _pad])
        if scaling_view.value:
            _bounds = _r["scaler"].transform(_bounds)
        for _points, _symbol, _name in [
            (_tr, "circle", "訓練"),
            (_te, "diamond", "テスト"),
        ]:
            scaling_fig.add_trace(
                go.Scatter(
                    x=_points[:, 0],
                    y=_points[:, 1],
                    mode="markers",
                    marker=dict(
                        color=_palette[scaling_labels],
                        symbol=_symbol,
                        size=8,
                        opacity=0.7,
                    ),
                    name=_name,
                    legendgroup=_name,
                    showlegend=_panel == 1,
                    customdata=scaling_labels,
                    hovertemplate="横=%{x:.2f}<br>縦=%{y:.2f}<br>正解=%{customdata}<extra>%{fullData.name}</extra>",
                ),
                row=1,
                col=_panel,
            )
        _lx, _ly = [], []
        for _i in _near:
            _lx.extend([_te[_focus, 0], _tr[_i, 0], None])
            _ly.extend([_te[_focus, 1], _tr[_i, 1], None])
        scaling_fig.add_trace(
            go.Scatter(
                x=_lx,
                y=_ly,
                mode="lines",
                line=dict(color="rgba(85,85,85,0.5)", width=1.5),
                name=f"近い{scaling_k.value}点",
                showlegend=_panel == 1,
                hoverinfo="skip",
            ),
            row=1,
            col=_panel,
        )
        scaling_fig.add_trace(
            go.Scatter(
                x=[_te[_focus, 0]],
                y=[_te[_focus, 1]],
                mode="markers",
                marker=dict(
                    symbol="star-open",
                    size=14,
                    color=_palette[scaling_labels[_focus]],
                    line=dict(color=_palette[scaling_labels[_focus]], width=2),
                ),
                name="選んだテスト点",
                showlegend=_panel == 1,
            ),
            row=1,
            col=_panel,
        )
        _wrong = _r["pred"] != scaling_labels
        scaling_fig.add_trace(
            go.Scatter(
                x=_te[_wrong, 0],
                y=_te[_wrong, 1],
                mode="markers",
                marker=dict(
                    symbol="x-open", color="rgba(34,34,34,0.7)", size=11, line=dict(width=1.5)
                ),
                name="誤分類",
                showlegend=_panel == 1,
                hoverinfo="skip",
            ),
            row=1,
            col=_panel,
        )
        _delta = (_r["train"][_near[0]] - _r["test"][_focus]) ** 2
        _rows.append(
            {
                "尺度を求める範囲": _r["name"],
                "40点の正解率": round(_r["accuracy"], 3),
                "横軸の除数": round(float(_r["divisor"][0]), 3),
                "縦軸の除数": round(float(_r["divisor"][1]), 3),
                "選択点の予測": int(_r["pred"][_focus]),
                "最近点までの横の距離²": round(float(_delta[0]), 3),
                "最近点までの縦の距離²": round(float(_delta[1]), 3),
            }
        )
        scaling_fig.update_xaxes(
            title_text="測定値", range=[_bounds[0, 0], _bounds[1, 0]], row=1, col=_panel
        )
        scaling_fig.update_yaxes(
            title_text="環境に左右される値",
            range=[_bounds[0, 1], _bounds[1, 1]],
            scaleanchor=("x" if _panel == 1 else "x2") if scaling_view.value else None,
            scaleratio=1,
            row=1,
            col=_panel,
        )
    scaling_fig.update_layout(
        height=460,
        template="plotly_white",
        legend=dict(orientation="h", y=-0.2),
        margin=dict(t=60, b=100),
        uirevision=str(scaling_view.value),
    )
    _good, _bad = scaling_results
    mo.vstack(
        [
            mo.md(
                f"訓練だけで求めると **{_good['accuracy']:.0%}**、テストを含めると **{_bad['accuracy']:.0%}**。差は **{100 * (_bad['accuracy'] - _good['accuracy']):+.0f}ポイント**。色は正解クラス（青=0、橙=1）。選択点の正解は **{scaling_labels[_focus]}**。"
            ),
            mo.md(
                "元データの散布図。点の色は正解クラス、×は誤分類を示す。丸は訓練、菱形はテスト、星から伸びる線は近傍を示す。元の座標では左右の点と軸の範囲をそろえている。縦横の1単位の長さは異なるので、画面上の線の長さを距離として読まない。"
            ),
            scaling_fig,
            mo.ui.table(_rows, selection=None),
            mo.md("""
    テスト側の縦軸が大きくばらつくと、テストを含めて求めた縦軸の除数が大きくなる。
    その結果、縦方向の差が距離に及ぼす影響が小さくなり、横方向で近い訓練点が選ばれる。
    表の距離²は、選択点と、それぞれの手順で最も近い訓練点との比較である。
    同じ尺度を両点に使うので、平均を引く操作は距離の差し引きで消える。ここで効くのは除数である。

    元データを見ると、訓練点は縦軸の−1と+1付近に集まり、テスト点は上下に大きく離れている。
    初期表示で選んだ青い星からの線は、左では橙の訓練点へ、右では青の訓練点へ伸びる。
    元データの点の位置は同じでも、右では縦方向の差が距離に及ぼす影響が小さくなり、横方向で近い点が選ばれる。
    振れ幅を10から0へ戻し、近傍の線と除数を比べる。
    変換後の座標に切り替えると、右側で縦軸が縮む様子も確認できる。

    これは、測定環境の変化がある場合に大差が出るよう作った例である。
    同じ分布から無作為に分けたデータでも常に大差が出る、という意味ではない。
    学習に使っていないデータをどれだけ正しく分類できるかを評価するには、
    変換に使う平均・標準偏差、または最小値・最大値を訓練データだけから計算し、テストデータにも同じ値を使う。
    予測対象のデータ全体を学習時に利用できるという設計なら、通常の未知データへの評価とは条件が異なることを明記する。

    「正規化」は処理を具体的に区別する。Min-Maxは各列の最小・最大を求めるため、
    求める範囲が問題になる。一方、各行をその行のL2ノルムで割る処理は他の行を使わず、
    それ自体はテスト集合から尺度を学ぶ漏洩にはならない。
    """),
        ]
    )
    return


@app.cell(hide_code=True)
def _(mo):
    _lead = mo.md(
        "## 同じ長編が両側に入ると\n    作品の行を分ける場合と、長編をまとめて分ける場合を切り替える。\n    **『三国志』の別の巻が訓練側に残っているか。**\n    下の帯は同じ作品順に固定してある。グループは著者名と題名の最初の部分から作る。"
    )
    grouped = mo.ui.switch(value=False, label="同じ長編をまとめる")
    fold = mo.ui.slider(1, 5, value=1, label="表示するフォールド", show_value=True)
    mo.vstack([_lead, mo.hstack([grouped, fold], wrap=True, justify="start", gap=2)])
    return fold, grouped


@app.cell(hide_code=True)
def _(
    KNeighborsClassifier,
    StandardScaler,
    StratifiedGroupKFold,
    X,
    experiment_seed,
    grouped,
    groups,
    make_pipeline,
    splits,
    y,
):
    group_splits = list(
        StratifiedGroupKFold(5, shuffle=True, random_state=experiment_seed.value).split(
            X, y, groups
        )
    )
    chosen_splits = group_splits if grouped.value else splits
    group_scores = []
    for _train, _test in chosen_splits:
        _model = make_pipeline(StandardScaler(), KNeighborsClassifier(5)).fit(X[_train], y[_train])
        group_scores.append(_model.score(X[_test], y[_test]))
    return chosen_splits, group_scores


@app.cell(hide_code=True)
def _(chosen_splits, fold, go, group_scores, groups, mo, np, titles, y):
    _train, _test = chosen_splits[fold.value - 1]
    overlap = sorted(set(groups[_train]) & set(groups[_test]))
    unseen = sorted(set(y[_test]) - set(y[_train]))
    _order = np.argsort(groups, kind="stable")
    _membership = np.zeros(len(y), dtype=int)
    _membership[_test] = 1
    split_fig = go.Figure(
        go.Heatmap(
            z=[_membership[_order]],
            x=list(range(len(y))),
            y=["分割"],
            zmin=0,
            zmax=1,
            colorscale=[
                [0, "#0072B2"],
                [0.499, "#0072B2"],
                [0.5, "#E69F00"],
                [1, "#E69F00"],
            ],
            showscale=False,
            text=[
                [
                    titles[i] + " / " + y[i] + (" / 検証" if _membership[i] else " / 訓練")
                    for i in _order
                ]
            ],
            hovertemplate="%{text}<extra></extra>",
        )
    )
    split_fig.update_layout(
        height=140,
        margin=dict(t=10, b=30),
        xaxis_title="作品(長編順に固定)",
        template="plotly_white",
    )
    _shared = "、".join(overlap) if overlap else "なし"
    _absent = "、".join(unseen) if unseen else "なし"
    mo.vstack(
        [
            split_fig,
            mo.md(
                f"青=訓練 **{len(_train)}作品**、黄=検証 **{len(_test)}作品**\n\n両側にある長編: **{_shared}**\n\n訓練側にいない著者: **{_absent}**\n\n5フォールド平均正解率 **{np.mean(group_scores):.3f}**。行を分ける評価と長編を分ける評価は、想定する未知データが違う。差のすべてを同じ条件での水増しと解釈することはできない。"
            ),
        ]
    )
    return


@app.cell(hide_code=True)
def _(mo):
    _lead = mo.md(
        "## 余分な次元を足す\n    見える3列は固定したまま、乱数の列を距離計算に加える。\n    **見た目が同じでも、近所の作品は同じままか。**"
    )
    extra = mo.ui.slider(
        steps=[0, 10, 50, 200, 1000], value=0, label="足す乱数の列数", show_value=True
    )
    focus = mo.ui.slider(0, 73, value=0, label="基準にする作品番号", show_value=True)
    mo.vstack([_lead, mo.hstack([extra, focus], wrap=True, justify="start", gap=2)])
    return extra, focus


@app.cell(hide_code=True)
def _(StandardScaler, X, colors, extra, focus, go, mo, np, titles, y):
    _base = StandardScaler().fit_transform(X[:, [0, 2, 3]])
    _noise = np.random.default_rng(2026).normal(size=(len(X), 1000))
    _noise = StandardScaler().fit_transform(_noise)
    _full = np.c_[_base, _noise[:, : extra.value]]
    _dist = np.linalg.norm(_full - _full[focus.value], axis=1)
    _dist[focus.value] = np.inf
    nearest = np.argsort(_dist)[:5]
    _original = np.linalg.norm(_base - _base[focus.value], axis=1)
    _original[focus.value] = np.inf
    retained = len(set(nearest) & set(np.argsort(_original)[:5]))
    curse = go.Figure()
    for _author in sorted(set(y)):
        _idx = np.where(y == _author)[0]
        curse.add_trace(
            go.Scatter3d(
                x=_base[_idx, 0],
                y=_base[_idx, 1],
                z=_base[_idx, 2],
                mode="markers",
                name=_author,
                text=np.array(titles)[_idx],
                marker=dict(size=4, color=colors[_author], opacity=0.75),
            )
        )
    _lines = np.full((15, 3), np.nan)
    _lines[::3] = _base[focus.value]
    _lines[1::3] = _base[nearest]
    curse.add_trace(
        go.Scatter3d(
            x=_lines[:, 0],
            y=_lines[:, 1],
            z=_lines[:, 2],
            mode="lines",
            line=dict(width=3, color="rgba(213,94,0,0.6)"),
            name="全次元での近傍5作品",
            hoverinfo="skip",
        )
    )
    curse.add_trace(
        go.Scatter3d(
            x=[_base[focus.value, 0]],
            y=[_base[focus.value, 1]],
            z=[_base[focus.value, 2]],
            mode="markers",
            marker=dict(
                size=9,
                symbol="diamond-open",
                color=colors[y[focus.value]],
                line=dict(width=2, color=colors[y[focus.value]]),
            ),
            name="基準作品",
            hoverinfo="skip",
        )
    )
    curse.update_layout(
        height=520,
        template="plotly_white",
        uirevision="curse-camera",
        scene=dict(
            aspectmode="data",
            xaxis_title="平仮名(標準化)",
            yaxis_title="漢字(標準化)",
            zaxis_title="文長mu(標準化)",
        ),
        margin=dict(t=20, l=0, r=0, b=0),
    )
    mo.vstack(
        [
            curse,
            mo.md(
                f"基準: **{titles[focus.value]}** / 乱数を足す前と共通する近傍 **{retained}/5作品**。座標と乱数の先頭列は固定し、使う乱数列数だけを変えている。赤い線は **{3 + extra.value}次元**で選んだ近傍である。"
            ),
        ]
    )
    return


if __name__ == "__main__":
    app.run()
