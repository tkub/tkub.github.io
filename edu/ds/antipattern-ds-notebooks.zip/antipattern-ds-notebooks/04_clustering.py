# /// script
# requires-python = ">=3.12"
# dependencies = ["marimo>=0.24", "polars>=1.0", "numpy>=2.0", "scipy>=1.14", "scikit-learn>=1.5", "plotly>=5.24", "regex>=2024.9"]
# ///

import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _():
    import marimo as mo
    import numpy as np
    import polars as pl
    import plotly.express as px
    import plotly.graph_objects as go
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    return PCA, StandardScaler, go, mo, np, pl, px


@app.cell(hide_code=True)
def _(mo, pl):
    df = pl.read_csv(str(mo.notebook_location() / "public" / "features.csv"))
    cols = [c for c in df.columns if c not in ("著者", "題名", "区分")]
    X = df.select(cols).to_numpy()
    y = df["著者"].to_numpy()
    titles = df["題名"].to_list()
    return X, cols, titles, y


@app.cell(hide_code=True)
def _(mo):
    mo.md("""
    # クラスタができるまで
    第5・6章の授業用。まず著者名を伏せ、同じ作品をどうまとめるかを見る。
    **k-meansの初期値を変えると、最後の分け方まで変わるか。**
    反復を0から進め、中心の移動と平方和を比べる。Ward法では木を切る高さを変える。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    block = mo.ui.dropdown(
        ["全52列", "字種3列", "文長2列", "読点前47列"], value="全52列", label="使う特徴"
    )
    scale = mo.ui.switch(value=True, label="標準化")
    method = mo.ui.radio(
        ["k-means", "Ward法"], value="k-means", inline=True, label="手法"
    )
    k = mo.ui.slider(2, 12, value=8, label="k-meansのクラスタ数", show_value=True)
    seed = mo.ui.slider(0, 19, value=0, label="初期値の番号", show_value=True)
    step = mo.ui.slider(0, 15, value=0, label="k-meansの反復回数", show_value=True)
    cut = mo.ui.slider(1, 99, value=55, label="Ward法の高さ(最大の%)", show_value=True)
    reveal = mo.ui.switch(value=False, label="著者名とARIを表示")
    links = mo.ui.switch(value=True, label="中心への線を表示")
    mo.vstack(
        [
            mo.hstack([block, scale, method], wrap=True, justify="start", gap=2),
            mo.hstack([k, seed, step], wrap=True, justify="start", gap=2),
            mo.hstack([cut, reveal, links], wrap=True, justify="start", gap=2),
        ]
    )
    return block, cut, k, links, method, reveal, scale, seed, step


@app.cell(hide_code=True)
def _(PCA, StandardScaler, X, block, cols, np, scale):
    _use = {
        "全52列": cols,
        "字種3列": cols[:3],
        "文長2列": cols[3:5],
        "読点前47列": cols[5:],
    }[block.value]
    raw = X[:, [cols.index(c) for c in _use]]
    A = StandardScaler().fit_transform(raw) if scale.value else raw.copy()
    projector = PCA(n_components=min(3, A.shape[1])).fit(A)

    def project(points):
        z = projector.transform(points)
        return np.pad(z, ((0, 0), (0, 3 - z.shape[1])))

    Z = project(A)
    return A, Z, project, projector


@app.cell(hide_code=True)
def _(A, k, np, seed):
    # Lloydの反復。空になったクラスタの中心はその場に残す。
    _centers = A[
        np.random.default_rng(seed.value).choice(len(A), k.value, replace=False)
    ].copy()
    history = []
    for _iteration in range(16):
        _d2 = ((A[:, None, :] - _centers[None, :, :]) ** 2).sum(axis=2)
        _labels = _d2.argmin(axis=1)
        history.append((_centers.copy(), _labels.copy(), float(_d2.min(axis=1).sum())))
        _centers = np.array(
            [
                A[_labels == j].mean(axis=0) if np.any(_labels == j) else _centers[j]
                for j in range(k.value)
            ]
        )
    return (history,)


@app.cell(hide_code=True)
def _(A, cut, history, method, step):
    from scipy.cluster.hierarchy import linkage, fcluster, dendrogram
    from sklearn.metrics import adjusted_rand_score, silhouette_score

    ward = linkage(A, method="ward")
    height = ward[-1, 2] * cut.value / 100
    centers, km_labels, objective = history[step.value]
    labels = (
        km_labels
        if method.value == "k-means"
        else fcluster(ward, height, criterion="distance") - 1
    )
    sil = silhouette_score(A, labels) if 1 < len(set(labels)) < len(A) else None
    return (
        adjusted_rand_score,
        centers,
        dendrogram,
        height,
        labels,
        objective,
        sil,
        ward,
    )


@app.cell(hide_code=True)
def _(
    Z,
    centers,
    go,
    labels,
    links,
    method,
    np,
    project,
    px,
    reveal,
    titles,
    y,
):
    fig = px.scatter_3d(
        x=Z[:, 0],
        y=Z[:, 1],
        z=Z[:, 2],
        color=[str(x + 1) for x in labels],
        color_discrete_map={
            str(i + 1): px.colors.qualitative.Dark24[i % 24] for i in range(74)
        },
        hover_name=[t + (" / " + a if reveal.value else "") for t, a in zip(titles, y)],
        labels={"color": "クラスタ", "x": "PC1", "y": "PC2", "z": "PC3"},
    )
    if method.value == "k-means":
        _c = project(centers)
        fig.add_trace(
            go.Scatter3d(
                x=_c[:, 0],
                y=_c[:, 1],
                z=_c[:, 2],
                mode="markers",
                name="中心",
                marker=dict(size=9, symbol="diamond", color="#111827"),
            )
        )
        if links.value:
            _lines = np.full((len(Z) * 3, 3), np.nan)
            _lines[::3] = Z
            _lines[1::3] = _c[labels]
            fig.add_trace(
                go.Scatter3d(
                    x=_lines[:, 0],
                    y=_lines[:, 1],
                    z=_lines[:, 2],
                    mode="lines",
                    line=dict(width=2, color="#9CA3AF"),
                    showlegend=False,
                    hoverinfo="skip",
                )
            )
    fig.update_traces(marker_size=5, selector=dict(type="scatter3d", mode="markers"))
    if method.value == "k-means":
        fig.data[len(set(labels))].marker.size = 9
    fig.update_layout(
        height=620,
        template="plotly_white",
        uirevision="cluster-camera",
        scene=dict(aspectmode="data"),
        margin=dict(l=0, r=0, t=30, b=0),
    )
    fig
    return


@app.cell(hide_code=True)
def _(
    adjusted_rand_score,
    labels,
    method,
    mo,
    objective,
    projector,
    reveal,
    sil,
    y,
):
    _sil = "定義できない" if sil is None else f"{sil:.3f}"
    _ari = f" / ARI **{adjusted_rand_score(y, labels):.3f}**" if reveal.value else ""
    _j = f" / 平方和 **{objective:.2f}**" if method.value == "k-means" else ""
    mo.md(
        f"クラスタ数 **{len(set(labels))}** / シルエット **{_sil}**{_j}{_ari}\n\n図の3軸に残る分散は **{projector.explained_variance_ratio_.sum():.1%}**。分け方と指標は、射影前の選択した特徴で計算している。字種3列は合計1のため平面に乗り、文長2列ではPC3は0になる。"
    )
    return


@app.cell(hide_code=True)
def _(dendrogram, go, height, history, method, step, titles, ward):
    process = go.Figure()
    if method.value == "k-means":
        process.add_trace(
            go.Scatter(
                x=list(range(16)), y=[h[2] for h in history], mode="lines+markers"
            )
        )
        process.add_vline(x=step.value, line_color="#D55E00")
        process.update_layout(xaxis_title="反復回数", yaxis_title="クラスタ内平方和")
    else:
        _dd = dendrogram(ward, no_plot=True, labels=titles)
        for _xs, _ys in zip(_dd["icoord"], _dd["dcoord"]):
            process.add_trace(
                go.Scatter(
                    x=_xs,
                    y=_ys,
                    mode="lines",
                    line=dict(color="#0072B2"),
                    showlegend=False,
                    hoverinfo="skip",
                )
            )
        process.add_hline(y=height, line_color="#D55E00")
        process.update_layout(
            xaxis=dict(showticklabels=False, title="作品"), yaxis_title="併合の高さ"
        )
    process.update_layout(height=300, template="plotly_white", margin=dict(t=20, b=40))
    process
    return


@app.cell(hide_code=True)
def _(labels, mo, pl, reveal, y):
    if reveal.value:
        _table = (
            pl.DataFrame({"著者": y, "クラスタ": labels + 1})
            .group_by(["著者", "クラスタ"])
            .len()
            .pivot(on="クラスタ", index="著者", values="len")
            .fill_null(0)
            .sort("著者")
        )
        mo.output.replace(mo.ui.table(_table, selection=None))
    else:
        mo.output.replace(
            mo.md(
                "初期値を変え、平方和が小さい分け方を探す。著者名を表示してから、平方和とARIが同じ分け方を支持するか比べる。ARIを見て選んだ設定の成績は、独立した評価にはならない。"
            )
        )
    return


if __name__ == "__main__":
    app.run()
