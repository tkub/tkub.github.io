# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "marimo>=0.24",
#     "polars>=1.0",
#     "numpy>=2.0",
#     "scipy>=1.14",
#     "scikit-learn>=1.5",
#     "plotly>=6.0",
#     "regex>=2024.9",
#     "duckdb==1.5.5",
#     "sqlglot==30.18.0",
# ]
#
# [tool.marimo.runtime]
# auto_instantiate = true
# on_cell_change = "autorun"
# ///

import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # 生の文章から作家を当てるまで

    『アンチパターンで学ぶデータ分析 ── 作家の判別を題材に』の流れを、1本のノートブックで追う。
    本文で扱う順に、**数える(第2章)→ 特徴を設計する(第3章)→ 距離を測る(第4章)→
    まとまりを見つける(第5章)→ 次元を減らす(第6章)→ 著者を当てて正しく測る(第7〜9章)→
    ジャンルを分ける(第11章)** と進む。

    コードは折りたたんである。各セルの左端の「コードを表示」を押すと開く
    (`marimo run` で開いた場合は、右上のメニューからコードの表示を切り替える)。
    前半は配布した数作品の本文を実際に数え、
    後半は同じ関数で全134作品(近代文学74作品+ライトノベル60区間)から作った特徴量の表を使う。
    ライトノベルは著作権が存続しているので本文は配らず、特徴量だけを扱う。
    """)
    return


@app.cell(hide_code=True)
def _():
    import marimo as mo
    import numpy as np
    import polars as pl
    import plotly.express as px
    import plotly.graph_objects as go
    import regex
    from collections import Counter

    return Counter, go, mo, np, pl, px, regex


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 0. 準備 ── 青空文庫の本文を読む

    青空文庫のテキストにはルビ `《かす》`、注記 `［＃…］`、ルビの始まりを示す `｜` が混じる。
    文字を数える前にこれを取り除く。ファイルの先頭2行は題名と著者、
    本文は2本目の罫線のあとから「底本」の行の前までである。
    """)
    return


@app.cell(hide_code=True)
def _(mo, regex):
    SAMPLES = mo.notebook_location() / "public" / "samples"

    RUBY = regex.compile(r"《[^》]+》")
    ANNOTATION = regex.compile(r"［＃[^］]+］")

    def strip_annotations(text: str) -> str:
        text = RUBY.sub("", text.replace("｜", ""))
        return ANNOTATION.sub("", text)

    def read_aozora(path) -> tuple[str, str, str]:
        """(題名, 著者, 本文) を返す。"""
        lines = [line.strip().replace("　", "") for line in path.read_text(encoding="utf-8").splitlines()]
        title, author = lines[0], lines[1]
        seps = [i for i, line in enumerate(lines[:60]) if line.startswith("-----")]
        start = seps[-1] + 1 if seps else 2
        end = next((i for i in range(start, len(lines)) if lines[i].startswith("底本")), len(lines))
        body = "\n".join(strip_annotations(line) for line in lines[start:end])
        return title, author, body

    works = {}
    for _name in ["shayo", "hashire_merosu", "kogyoku", "namiki"]:
        _title, _author, _body = read_aozora(SAMPLES / f"{_name}.txt")
        works[_title] = {"著者": _author, "本文": _body}

    {t: (w["著者"], f"{len(w['本文']):,}文字") for t, w in works.items()}
    return SAMPLES, works


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. テキストを数える(第2章)

    分析は数えるところから始まる。まず英語の『赤毛のアン』で **Zipf の法則** を確かめる。
    単語を出現回数の多い順に並べ、順位を横軸、回数を縦軸にとって両対数で描くと、ほぼ直線になる。
    少数の語(the, and, to …)が大半を占め、大多数の語はごくまれにしか出ない。
    """)
    return


@app.cell(hide_code=True)
def _(Counter, SAMPLES, go, regex):
    anne = SAMPLES.joinpath("anne.txt").read_text(encoding="utf-8", errors="ignore")
    anne_words = regex.sub(r"[,.?!:\";()'#_\-]", " ", anne).lower().split()
    anne_freq = Counter(anne_words).most_common()

    zipf = go.Figure()
    zipf.add_trace(
        go.Scatter(
            x=list(range(1, len(anne_freq) + 1)),
            y=[c for _, c in anne_freq],
            mode="markers",
            marker=dict(size=4, color="#0072B2", opacity=0.6),
            text=[w for w, _ in anne_freq],
            hovertemplate="%{text}<br>順位 %{x}<br>回数 %{y}<extra></extra>",
        )
    )
    zipf.update_layout(
        height=380,
        template="plotly_white",
        xaxis=dict(type="log", title="順位"),
        yaxis=dict(type="log", title="出現回数"),
        title=f"『赤毛のアン』の単語 {len(anne_freq):,} 種類(延べ {len(anne_words):,} 語)",
        margin=dict(t=50, b=40),
    )
    zipf
    return (anne_freq,)


@app.cell(hide_code=True)
def _(anne_freq, mo):
    _top = ", ".join(f"{w} ({c:,})" for w, c in anne_freq[:8])
    mo.md(f"""
    上位8語: {_top}。どれも **機能語**(冠詞・接続詞・前置詞)である。
    文体の手がかりになるのは、話題によらず誰の文章にも現れるこの種の語や記号の使い方であって、
    内容語(登場人物の名前、題材の語)ではない。第9章で、内容語を拾ってしまう特徴の罠を見る。

    日本語には分かち書きがないので、単語の代わりに **文字** を数えても同じ形が現れる。
    """)
    return


@app.cell(hide_code=True)
def _(Counter, go, works):
    _body = works["斜陽"]["本文"]
    char_freq = Counter(c for c in _body if not c.isspace()).most_common()

    zipf_ja = go.Figure(
        go.Scatter(
            x=list(range(1, len(char_freq) + 1)),
            y=[c for _, c in char_freq],
            mode="markers",
            marker=dict(size=4, color="#D55E00", opacity=0.6),
            text=[c for c, _ in char_freq],
            hovertemplate="「%{text}」<br>順位 %{x}<br>回数 %{y}<extra></extra>",
        )
    )
    zipf_ja.update_layout(
        height=380,
        template="plotly_white",
        xaxis=dict(type="log", title="順位"),
        yaxis=dict(type="log", title="出現回数"),
        title=f"『斜陽』の文字 {len(char_freq):,} 種類",
        margin=dict(t=50, b=40),
    )
    zipf_ja
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. 特徴を設計する(第3章)

    作家を当てるのに、何を数えるか。**題材ではなく書き手の癖** が出るものを選ぶ。
    本書では3種類を使う。

    1. **字種の比率**: 平仮名・片仮名・漢字がそれぞれ全体の何割か
    2. **文長の分布**: 文の長さ(文字数)の対数をとった平均 μ と標準偏差 σ
    3. **読点の前の平仮名**: 「は、」「が、」「て、」… 読点をどこで打つか

    それぞれ関数を定義し、配布した作品で試す。
    """)
    return


@app.cell(hide_code=True)
def _(pl, regex, works):
    def char_type_ratio(text: str) -> dict[str, float]:
        counts = {
            "平仮名": len(regex.findall(r"\p{Hiragana}", text)),
            "片仮名": len(regex.findall(r"\p{Katakana}", text)),
            "漢字": len(regex.findall(r"\p{Han}", text)),
        }
        total = sum(counts.values()) or 1
        return {k: v / total for k, v in counts.items()}

    ratio_table = pl.DataFrame(
        [{"題名": t, "著者": w["著者"], **char_type_ratio(w["本文"])} for t, w in works.items()]
    )
    ratio_table
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    3つの比率は足すと1になる。**3つの数に見えて自由度は2** しかなく、
    平仮名が増えれば漢字は減るしかない。あとで散布図に負の相関が現れるが、
    それだけでは文体の性質を示したことにならない(第3章「組成データ」)。
    """)
    return


@app.cell(hide_code=True)
def _(go, np, regex, works):
    NOISE = regex.compile(r"[\s、。！？（）「」『』〈〉]+")

    def sentence_lengths(text: str) -> np.ndarray:
        """「。」「！」「？」で文に切り、記号を除いた文字数を返す。"""
        sentences = regex.split(r"[。！？]", text)
        lengths = [len(NOISE.sub("", s)) for s in sentences]
        return np.array([n for n in lengths if n > 0])

    def sentence_length_stats(text: str) -> dict[str, float]:
        log_len = np.log(sentence_lengths(text))
        return {"文長mu": float(log_len.mean()), "文長sigma": float(log_len.std())}

    _lengths = sentence_lengths(works["斜陽"]["本文"])
    _log = np.log(_lengths)
    _mu, _sigma = _log.mean(), _log.std()
    _x = np.linspace(_log.min(), _log.max(), 200)
    _pdf = np.exp(-((_x - _mu) ** 2) / (2 * _sigma**2)) / (_sigma * np.sqrt(2 * np.pi))

    length_fig = go.Figure()
    length_fig.add_trace(
        go.Histogram(
            x=_log, nbinsx=40, histnorm="probability density", name="文長(対数)",
            marker=dict(color="#0072B2", opacity=0.6),
        )
    )
    length_fig.add_trace(
        go.Scatter(x=_x, y=_pdf, mode="lines", name=f"正規分布 μ={_mu:.2f}, σ={_sigma:.2f}",
                   line=dict(color="#D55E00", width=2))
    )
    length_fig.update_layout(
        height=340, template="plotly_white",
        title=f"『斜陽』の文長 {len(_lengths):,} 文(中央値 {np.median(_lengths):.0f} 文字)",
        xaxis_title="log(文字数)", yaxis_title="密度",
        legend=dict(orientation="h", y=1.1), margin=dict(t=60, b=40),
    )
    length_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    文長そのものは右に長く裾を引くが、対数をとると左右対称の山に近づく(**対数正規分布**)。
    山の位置 μ と幅 σ の2つの数で、その作品の文の長さの癖を表す。
    """)
    return


@app.cell(hide_code=True)
def _(Counter, go, regex, works):
    COMMA_PATTERN = regex.compile(r"(\p{Hiragana})、")

    def hiragana_before_comma(text: str) -> dict[str, float]:
        """読点の直前の平仮名を数え、合計1に正規化する。"""
        counts = Counter(COMMA_PATTERN.findall(text))
        counts.pop("ゝ", None)
        counts.pop("ゞ", None)
        total = sum(counts.values()) or 1
        return {c: n / total for c, n in counts.items()}

    comma_fig = go.Figure()
    for _title, _color in [("斜陽", "#0072B2"), ("紅玉", "#D55E00")]:
        _ratio = hiragana_before_comma(works[_title]["本文"])
        _top = sorted(_ratio.items(), key=lambda kv: -kv[1])[:15]
        comma_fig.add_trace(
            go.Bar(x=[c for c, _ in _top], y=[r for _, r in _top],
                   name=f"{_title}({works[_title]['著者']})", marker=dict(color=_color, opacity=0.75))
        )
    comma_fig.update_layout(
        height=340, template="plotly_white", barmode="group",
        xaxis_title="読点の直前の平仮名(各作品の上位15)", yaxis_title="割合",
        legend=dict(orientation="h", y=1.1), margin=dict(t=40, b=40),
    )
    comma_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    太宰は「て、」「が、」で切り、鏡花は「と、」「に、」が目立つ。
    どちらも意識して選ぶ書き方ではないので、書き手ごとに安定した癖になる。

    ### 全作品の特徴量の表

    上の3つの関数を全134作品に適用したものが `public/features_all.csv` である
    (読点前の平仮名は、平均頻度が0.1%未満の文字を落として47列にしてある)。
    以降はこの表を使う。
    """)
    return


@app.cell(hide_code=True)
def _(mo, np, pl):
    df = pl.read_csv(str(mo.notebook_location() / "public" / "features_all.csv"))
    META = ["著者", "題名", "区分"]
    feature_cols = [c for c in df.columns if c not in META]
    X_all = df.select(feature_cols).to_numpy()
    authors = df["著者"].to_numpy()
    titles = df["題名"].to_numpy()
    genre = np.where(df["区分"].to_numpy() == "novels", "近代文学", "ライトノベル")
    # 長編の巻を1つの群にまとめる(三国志_五丈原の巻 → 三国志、薬屋のひとりごと01 → 薬屋のひとりごと)
    series = np.array([t.split("_")[0].rstrip("0123456789") for t in titles])
    is_novel = genre == "近代文学"

    _palette = [
        "#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#332288", "#882255",
        "#117733", "#88CCEE", "#DDCC77", "#AA4499", "#44AA99", "#999933",
    ]
    _names = sorted(set(authors[is_novel])) + sorted(set(authors[~is_novel]))
    author_color = dict(zip(_names, _palette))
    genre_symbol = {"近代文学": "circle", "ライトノベル": "diamond"}
    # plotly express に渡す用。区分は日本語にしておく
    plot_df = df.select(["題名", "著者", "平仮名", "片仮名", "漢字", "文長mu"]).with_columns(
        pl.Series("区分", genre)
    )
    mo.md(
        f"**{len(df)} 作品 × {len(feature_cols)} 列**(字種3 + 文長2 + 読点前{len(feature_cols) - 5})。"
        f"著者 {len(set(authors))} 名、長編・シリーズをまとめると {len(set(series))} 群。"
    )
    return (
        X_all,
        author_color,
        authors,
        df,
        feature_cols,
        genre,
        genre_symbol,
        is_novel,
        plot_df,
        series,
        titles,
    )


@app.cell(hide_code=True)
def _(author_color, df, genre_symbol, np, plot_df, px):
    _r = np.corrcoef(df["平仮名"].to_numpy(), df["漢字"].to_numpy())[0, 1]
    chars_fig = px.scatter(
        plot_df, x="平仮名", y="漢字", color="著者", symbol="区分",
        color_discrete_map=author_color, symbol_map=genre_symbol,
        hover_name="題名", labels={"平仮名": "平仮名の比率", "漢字": "漢字の比率"},
        title=f"字種の比率(平仮名と漢字の相関 r = {_r:+.3f})",
    )
    chars_fig.update_traces(marker=dict(size=7, opacity=0.75))
    chars_fig.update_layout(height=520, template="plotly_white", margin=dict(t=50, b=40))
    chars_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    強い負の相関に見えるが、平仮名+片仮名+漢字=1 なので、この向きは制約から出る。
    合計1の3成分は、3次元空間の中の **三角形(単体)の上** にしか乗らない。
    その三角形を正面から見たのが **三角図(ternary plot)** で、3つの比率を1枚に無理なく描ける。
    """)
    return


@app.cell(hide_code=True)
def _(author_color, genre_symbol, plot_df, px):
    ternary_fig = px.scatter_ternary(
        plot_df, a="平仮名", b="漢字", c="片仮名", color="著者", symbol="区分",
        color_discrete_map=author_color, symbol_map=genre_symbol, hover_name="題名",
        title="字種の比率の三角図(片仮名の頂点は左下。片仮名は少ないので、点は平仮名−漢字の辺の近くに集まる)",
    )
    ternary_fig.update_traces(marker=dict(size=7, opacity=0.75))
    ternary_fig.update_layout(height=560, template="plotly_white", margin=dict(t=60, b=40))
    ternary_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    点が辺に貼りついて見えるのは、片仮名が数%しかないからである。
    片仮名の軸を拡大したいなら比率のまま眺めるより **対数比** で見るほうがよい(第3章の clr・ilr)。
    ライトノベル(菱形)は平仮名−漢字の辺から少し内側、つまり **片仮名が多い** 側にずれる。
    それは次の箱ひげ図のほうがよく分かる。
    """)
    return


@app.cell(hide_code=True)
def _(author_color, plot_df, px):
    kata_fig = px.box(
        plot_df, x="著者", y="片仮名", color="著者", color_discrete_map=author_color,
        points="all", hover_name="題名",
        labels={"片仮名": "片仮名の比率"},
        category_orders={"著者": list(author_color)},
        title="著者ごとの片仮名の比率(左8名が近代文学、右6名がライトノベル)",
    )
    kata_fig.update_traces(marker=dict(size=5, opacity=0.6), showlegend=False)
    kata_fig.update_layout(height=420, template="plotly_white", margin=dict(t=50, b=40))
    kata_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. 距離を測る(第4章)

    作品どうしの「近さ」を数にする。52列をそのまま使うと、
    **文長 μ(値が3前後)が比率の列(0.0x)を圧倒** し、距離は文長だけで決まってしまう。
    列ごとに平均0・標準偏差1にそろえる(**標準化**)と、どの列も同じ重みで効く。

    使う列と標準化の有無を切り替えて、距離行列がどう変わるかを見る。
    行と列は著者順に並べてある。同じ著者どうしが近ければ、対角線に沿った塊が見える。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    feature_set = mo.ui.dropdown(
        options=["全52列", "字種3列", "文長2列", "読点前47列"], value="全52列", label="使う特徴"
    )
    standardize = mo.ui.switch(value=True, label="標準化する")
    mo.hstack([feature_set, standardize], justify="start", gap=2)
    return feature_set, standardize


@app.cell(hide_code=True)
def _(X_all, feature_cols, feature_set, np, standardize):
    from sklearn.preprocessing import StandardScaler

    _groups = {
        "全52列": feature_cols,
        "字種3列": ["平仮名", "片仮名", "漢字"],
        "文長2列": ["文長mu", "文長sigma"],
        "読点前47列": [c for c in feature_cols if c not in ("平仮名", "片仮名", "漢字", "文長mu", "文長sigma")],
    }
    used_cols = _groups[feature_set.value]
    _idx = [feature_cols.index(c) for c in used_cols]
    X_raw = X_all[:, _idx]
    X = StandardScaler().fit_transform(X_raw) if standardize.value else X_raw
    _sd = X_raw.std(axis=0)
    scale_note = (
        f"生の標準偏差の最大/最小 = {_sd.max():.3f} / {_sd.min():.4f}"
        f"(最大は「{used_cols[int(np.argmax(_sd))]}」)"
    )
    return StandardScaler, X, scale_note


@app.cell(hide_code=True)
def _(X, author_color, authors, go, is_novel, mo, np, scale_note, titles):
    from scipy.spatial.distance import pdist, squareform

    D = squareform(pdist(X))
    _order = np.lexsort((titles, np.array([list(author_color).index(a) for a in authors])))
    _labels = [f"{titles[i]}({authors[i]})" for i in _order]
    _pairs = [[f"{a}<br>{b}" for a in _labels] for b in _labels]
    dist_fig = go.Figure(
        go.Heatmap(
            z=D[np.ix_(_order, _order)], text=_pairs,
            colorscale="Blues", reversescale=True, colorbar=dict(title="距離"),
            hovertemplate="%{text}<br>距離 %{z:.2f}<extra></extra>",
        )
    )
    _n_novel = int(is_novel.sum()) - 0.5
    dist_fig.add_shape(type="line", x0=_n_novel, x1=_n_novel, y0=-0.5, y1=len(D) - 0.5, line=dict(color="#D55E00", width=1))
    dist_fig.add_shape(type="line", y0=_n_novel, y1=_n_novel, x0=-0.5, x1=len(D) - 0.5, line=dict(color="#D55E00", width=1))
    dist_fig.update_layout(
        height=620, template="plotly_white", margin=dict(t=30, b=0, l=0, r=0),
        xaxis=dict(showticklabels=False), yaxis=dict(showticklabels=False, autorange="reversed"),
    )
    mo.vstack([mo.md(f"ユークリッド距離。橙の線が近代文学とライトノベルの境。{scale_note}"), dist_fig])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    「文長2列」を標準化なしで選ぶと、距離はほとんど文長 μ の差だけになる。
    「全52列」を標準化なしにすると、実はそれとほぼ同じ図になる ── 52列あっても文長に支配されているからである。
    標準化すると読点前の47列が効き始め、著者ごとの塊がはっきりする。

    ## 4. まとまりを見つける(第5章)

    距離が決まれば、近いものどうしをまとめられる。**Ward 法の階層クラスタリング** は、
    まとめたときのクラスタ内のばらつきの増分が最小になる組を順に併合していく。
    その履歴が **デンドログラム(樹形図)** である。高いところで切れば少数の大きな塊、
    低いところで切れば多数の小さな塊になる。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    cut_ratio = mo.ui.slider(5, 100, value=60, step=5, label="木を切る高さ(最大の%)")
    cut_ratio
    return (cut_ratio,)


@app.cell(hide_code=True)
def _(X, author_color, authors, cut_ratio, genre, go, mo, np, titles):
    from scipy.cluster import hierarchy as sch
    from sklearn.metrics import adjusted_rand_score

    linkage = sch.linkage(X, method="ward")
    cut_height = linkage[:, 2].max() * cut_ratio.value / 100
    cluster_of = sch.fcluster(linkage, t=cut_height, criterion="distance")
    _dd = sch.dendrogram(linkage, no_plot=True, labels=list(range(len(X))))

    dendro = go.Figure()
    for _xs, _ys in zip(_dd["icoord"], _dd["dcoord"]):
        dendro.add_trace(
            go.Scatter(x=_xs, y=_ys, mode="lines", line=dict(color="#6B7280", width=1),
                       showlegend=False, hoverinfo="skip")
        )
    # 葉に著者の色の点を置く(近代文学は丸、ライトノベルは菱形)
    _leaf_x = np.arange(5, 10 * len(X), 10)
    for _author in author_color:
        _sel = [k for k, i in enumerate(_dd["leaves"]) if authors[i] == _author]
        if not _sel:
            continue
        _i = [_dd["leaves"][k] for k in _sel]
        dendro.add_trace(
            go.Scatter(
                x=_leaf_x[_sel], y=np.zeros(len(_sel)), mode="markers", name=_author,
                marker=dict(size=8, color=author_color[_author], opacity=0.85,
                            symbol="circle" if genre[_i[0]] == "近代文学" else "diamond"),
                text=[titles[i] for i in _i], hovertemplate="%{text}<extra>" + _author + "</extra>",
            )
        )
    dendro.add_hline(y=cut_height, line=dict(color="#D55E00", width=1.5, dash="dot"))
    dendro.update_layout(
        height=520, template="plotly_white", margin=dict(t=30, b=20, l=0, r=0),
        xaxis=dict(showticklabels=False, title="作品(葉の色が著者、丸が近代文学、菱形がライトノベル)"),
        yaxis_title="併合の高さ", legend=dict(orientation="h", y=-0.12),
    )
    _n = len(set(cluster_of))
    _ari_genre = adjusted_rand_score(genre, cluster_of)
    _ari_author = adjusted_rand_score(authors, cluster_of)
    mo.vstack([
        mo.md(f"切ると **{_n} クラスタ**。区分(近代文学/ラノベ)との一致 ARI = **{_ari_genre:.3f}**、著者との一致 ARI = **{_ari_author:.3f}**"),
        dendro,
    ])
    return (adjusted_rand_score,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    全52列を標準化して使うと、いちばん高いところで木が **近代文学とライトノベルに割れる**。
    著者名も区分も一切使っていないのに、文体の数値だけでそこまで分かれる。
    高さを下げていくと、近代文学の側では著者ごとの枝が現れる
    (『三国志』『宮本武蔵』の各巻は同じ枝に固まる)。「字種3列」だけでもラノベは分かれるが、
    著者までは分かれない。ARI は正解の分け方との一致度で、1が完全一致、0が偶然と同程度である。

    もう一つの代表的な方法が **k-means** である。クラスタ数 k を先に決め、
    各点を最も近い中心に割り当て、中心を割り当てられた点の平均に動かす、を繰り返す。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    k_clusters = mo.ui.slider(2, 16, value=8, label="k-means のクラスタ数")
    k_seed = mo.ui.slider(0, 9, value=0, label="初期値の番号")
    mo.hstack([k_clusters, k_seed], justify="start", gap=2)
    return k_clusters, k_seed


@app.cell(hide_code=True)
def _(X, adjusted_rand_score, authors, genre, k_clusters, k_seed, mo, pl):
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score

    kmeans = KMeans(n_clusters=k_clusters.value, n_init=1, random_state=k_seed.value).fit(X)
    _sil = silhouette_score(X, kmeans.labels_) if k_clusters.value > 1 else float("nan")
    # 各クラスタにどの著者が何作品入ったか
    _table = pl.DataFrame({"クラスタ": kmeans.labels_ + 1, "著者": authors, "区分": genre})
    crosstab = (
        _table.group_by(["クラスタ", "著者"]).len().pivot(on="著者", index="クラスタ", values="len")
        .fill_null(0).sort("クラスタ")
    )
    mo.vstack([
        mo.md(
            f"k = {k_clusters.value}: クラスタ内平方和 **{kmeans.inertia_:.1f}**、シルエット **{_sil:.3f}**、"
            f"著者との ARI **{adjusted_rand_score(authors, kmeans.labels_):.3f}**、"
            f"区分との ARI **{adjusted_rand_score(genre, kmeans.labels_):.3f}**"
        ),
        crosstab,
    ])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    初期値の番号を変えると、同じ k でも分け方が変わる(**局所解**)。
    k-means は平方和を減らす方向にしか動かないので、出発点しだいで違う谷に落ちる。
    実務では `n_init` を増やして最良を採るが、「最良を選ぶ」こと自体が第9章の多重テストと同じ構造を持つ。

    ## 5. 次元を減らす(第6章)

    52列を人の目で見るには2〜3次元に落とす。**主成分分析(PCA)** は、
    分散が最大になる方向から順に軸を取り直す。標準化した52列で行う。
    """)
    return


@app.cell(hide_code=True)
def _(StandardScaler, X_all, feature_cols, go, mo, np):
    from sklearn.decomposition import PCA

    X_std = StandardScaler().fit_transform(X_all)
    pca = PCA().fit(X_std)
    scores = pca.transform(X_std)
    _ratio = pca.explained_variance_ratio_
    scree = go.Figure()
    scree.add_trace(go.Bar(x=np.arange(1, 16), y=_ratio[:15], name="寄与率",
                           marker=dict(color="#0072B2", opacity=0.7)))
    scree.add_trace(go.Scatter(x=np.arange(1, 16), y=np.cumsum(_ratio)[:15], name="累積",
                               mode="lines+markers", line=dict(color="#D55E00")))
    scree.update_layout(height=320, template="plotly_white", xaxis_title="主成分", yaxis_title="分散の割合",
                        legend=dict(orientation="h", y=1.1), margin=dict(t=40, b=40))
    mo.vstack([
        mo.md(f"第1〜3主成分で全分散の **{np.cumsum(_ratio)[2]:.1%}**。残りの {len(feature_cols) - 3} 軸に {1 - np.cumsum(_ratio)[2]:.1%} が散らばっている。"),
        scree,
    ])
    return X_std, pca, scores


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    寄与率が小さい軸を捨てても失われるのは **分散** であって、著者を見分ける情報の割合ではない。
    2次元の地図で隣に見える作品が、52次元でも隣とは限らない(下の地図で確かめる)。

    ### バイプロット ── 軸の意味を読む

    主成分は52列の重みつき和である。各列の重み(負荷量)を矢印で重ねると、
    **どの列が地図のどの方向を作っているか** が読める。矢印は方角ごとに負荷の大きい列を選んで描いた。
    """)
    return


@app.cell(hide_code=True)
def _(
    author_color,
    authors,
    feature_cols,
    genre,
    genre_symbol,
    go,
    np,
    pca,
    scores,
    titles,
):
    _load = pca.components_[:2].T * np.sqrt(pca.explained_variance_[:2])
    _scale = float(np.abs(scores[:, :2]).max() / np.abs(_load).max()) * 0.95
    # 方角を8つに切り、各方角で負荷の最も大きい列を1つ選ぶ(矢印が束にならないように)
    _angle = np.arctan2(_load[:, 1], _load[:, 0])
    _sector = ((_angle + np.pi) // (np.pi / 4)).astype(int) % 8
    _chosen = [
        max((i for i in range(len(feature_cols)) if _sector[i] == s), key=lambda i: (_load[i] ** 2).sum())
        for s in range(8) if (_sector == s).any()
    ]

    biplot = go.Figure()
    for _author in author_color:
        _m = authors == _author
        if not _m.any():
            continue
        biplot.add_trace(
            go.Scatter(
                x=scores[_m, 0], y=scores[_m, 1], mode="markers", name=_author,
                marker=dict(size=6, color=author_color[_author], opacity=0.7, symbol=genre_symbol[genre[_m][0]]),
                text=titles[_m], hovertemplate="%{text}<extra>" + _author + "</extra>",
            )
        )
    for _i in _chosen:
        _x, _y = _load[_i] * _scale
        biplot.add_trace(go.Scatter(x=[0, _x], y=[0, _y], mode="lines", line=dict(color="rgba(213,94,0,0.7)", width=2),
                                    showlegend=False, hoverinfo="skip"))
        biplot.add_annotation(x=_x * 1.12, y=_y * 1.12, text=f"「{feature_cols[_i]}」" if len(feature_cols[_i]) == 1 else feature_cols[_i],
                              showarrow=False, font=dict(color="#D55E00", size=12))
    biplot.update_layout(
        height=560, template="plotly_white",
        xaxis_title=f"PC1({pca.explained_variance_ratio_[0]:.1%})",
        yaxis_title=f"PC2({pca.explained_variance_ratio_[1]:.1%})",
        margin=dict(t=30, b=40), legend=dict(orientation="h", y=-0.15),
    )
    biplot.update_yaxes(scaleanchor="x", scaleratio=1)
    biplot
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    片仮名の矢印がライトノベルの側を向き、読点前の「は」「が」などは近代文学の作家を分ける向きに出る。
    矢印どうしの角度が小さい列は、作品を横断して一緒に増減する列である。

    ### 地図に残らない距離

    2次元・3次元の地図で、作品を1つ選び、**52次元での近傍5作品** を線で結ぶ。
    線が長く伸びていれば、地図では遠くに置かれた作品が元の空間では近い、ということである。
    """)
    return


@app.cell(hide_code=True)
def _(mo, titles):
    map_dim = mo.ui.radio(options=["2次元", "3次元"], value="2次元", label="表示")
    focus = mo.ui.dropdown(options={t: i for i, t in enumerate(titles)}, value=str(titles[0]), label="基準作品")
    mo.hstack([map_dim, focus], justify="start", gap=2)
    return focus, map_dim


@app.cell(hide_code=True)
def _(
    X_std,
    author_color,
    authors,
    focus,
    genre,
    genre_symbol,
    go,
    map_dim,
    mo,
    np,
    scores,
    titles,
):
    _dim = 3 if map_dim.value == "3次元" else 2
    _f = focus.value
    _d = np.linalg.norm(X_std - X_std[_f], axis=1)
    _d[_f] = np.inf
    near = np.argsort(_d)[:5]
    _Z = scores[:, :_dim]
    _seg = np.full((15, _dim), np.nan)
    _seg[::3] = _Z[_f]
    _seg[1::3] = _Z[near]

    _Trace = go.Scatter3d if _dim == 3 else go.Scatter
    def _xyz(A):
        return dict(x=A[:, 0], y=A[:, 1], **({"z": A[:, 2]} if _dim == 3 else {}))

    pca_map = go.Figure()
    for _author in author_color:
        _m = authors == _author
        if not _m.any():
            continue
        pca_map.add_trace(_Trace(
            **_xyz(_Z[_m]), mode="markers", name=_author,
            marker=dict(size=4 if _dim == 3 else 6, color=author_color[_author], opacity=0.7,
                        symbol=genre_symbol[genre[_m][0]]),
            text=titles[_m], hovertemplate="%{text}<extra>" + _author + "</extra>",
        ))
    pca_map.add_trace(_Trace(**_xyz(_seg), mode="lines", name="52次元での近傍5作品",
                             line=dict(color="rgba(213,94,0,0.6)", width=3), hoverinfo="skip"))
    pca_map.add_trace(_Trace(**_xyz(_Z[[_f]]), mode="markers", name="基準作品", hoverinfo="skip",
                             marker=dict(size=9, symbol="diamond-open", color=author_color[authors[_f]],
                                         line=dict(width=2, color=author_color[authors[_f]]))))
    pca_map.update_layout(height=600, template="plotly_white", margin=dict(t=30, b=0, l=0, r=0),
                          uirevision=f"map-{_dim}", legend=dict(orientation="h", y=-0.1))
    if _dim == 2:
        pca_map.update_yaxes(scaleanchor="x", scaleratio=1)
        pca_map.update_layout(xaxis_title="PC1", yaxis_title="PC2")
    else:
        pca_map.update_layout(scene=dict(aspectmode="data", xaxis_title="PC1", yaxis_title="PC2", zaxis_title="PC3"))
    _near_2d = np.argsort(np.linalg.norm(_Z - _Z[_f], axis=1))[1:6]
    _overlap = len(set(near) & set(_near_2d))
    mo.vstack([
        mo.md(f"『{titles[_f]}』({authors[_f]})の52次元での近傍: "
              + "、".join(f"{titles[i]}({authors[i]})" for i in near)
              + f"。この{_dim}次元の地図での近傍5作品と **{_overlap}/5** 一致。"),
        pca_map,
    ])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 6. 著者を当て、正しく測る(第7〜9章)

    ここからは正解(著者名)を使う **教師あり学習**。近代文学74作品で、
    k近傍法とランダムフォレストを **5分割交差検証** で測る。

    分け方は2通り試す。作品を無作為に5つに分ける **層別CV** と、
    同じ長編(『三国志』全11巻、『宮本武蔵』全7巻…)が訓練と検証の両方に入らないようにする **グループCV**。
    前者は「同じ長編の別の巻を当てる」問題、後者は「新しい長編を当てる」問題を測っている。
    """)
    return


@app.cell(hide_code=True)
def _(StandardScaler, X_all, authors, is_novel, mo, np, pl, series):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold, cross_val_predict, cross_val_score
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.pipeline import make_pipeline

    X_nov, y_nov, g_nov = X_all[is_novel], authors[is_novel], series[is_novel]
    skf = StratifiedKFold(5, shuffle=True, random_state=0)
    sgkf = StratifiedGroupKFold(5, shuffle=True, random_state=0)
    models = {
        "k近傍法(k=5)": lambda: make_pipeline(StandardScaler(), KNeighborsClassifier(5)),
        "ランダムフォレスト": lambda: RandomForestClassifier(n_estimators=300, random_state=0),
    }
    _rows = []
    for _name, _mk in models.items():
        _a = cross_val_score(_mk(), X_nov, y_nov, cv=skf).mean()
        _b = cross_val_score(_mk(), X_nov, y_nov, cv=sgkf, groups=g_nov).mean()
        _rows.append({"モデル": _name, "層別CV": round(_a, 3), "グループCV": round(_b, 3), "差": round(_a - _b, 3)})
    _majority = np.unique(y_nov, return_counts=True)[1].max() / len(y_nov)
    mo.vstack([
        pl.DataFrame(_rows),
        mo.md(f"基準線(最頻クラス「吉川英治」と答え続ける): **{_majority:.3f}**。標準化はパイプラインの中で、各分割の訓練側だけから行っている。"),
    ])
    return X_nov, cross_val_predict, models, skf, y_nov


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    この特徴量では2つの分け方の差が小さい。字種・文長・読点の癖には『三国志』という物語も
    登場人物の名前も入っていないからで、特徴設計が狙いどおりに働いた結果である
    (第9章では、文字 n-gram に替えると差が開き、登場人物の名前を覚えていることを確かめる)。

    どの著者を取り違えるかは **混同行列** で見る。
    """)
    return


@app.cell(hide_code=True)
def _(X_nov, cross_val_predict, go, models, np, skf, y_nov):
    from sklearn.metrics import confusion_matrix

    _pred = cross_val_predict(models["ランダムフォレスト"](), X_nov, y_nov, cv=skf)
    _labels = sorted(set(y_nov))
    _cm = confusion_matrix(y_nov, _pred, labels=_labels)
    conf_fig = go.Figure(
        go.Heatmap(z=_cm, x=_labels, y=_labels, colorscale="Blues", text=_cm, texttemplate="%{text}",
                   showscale=False, hovertemplate="正解 %{y}<br>予測 %{x}<br>%{z} 作品<extra></extra>")
    )
    conf_fig.update_layout(height=420, template="plotly_white", xaxis_title="予測", yaxis_title="正解",
                           yaxis=dict(autorange="reversed"), margin=dict(t=30, b=40),
                           title=f"ランダムフォレスト、層別5分割CV(正解率 {np.mean(_pred == y_nov):.3f})")
    conf_fig
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 7. ジャンルを分ける(第11章)

    ライトノベルを加えた134作品で、近代文学かライトノベルかを当てる。
    第2節の箱ひげ図で見たとおり、**片仮名の比率1列** でほぼ解ける。
    しきい値を動かして、正解率がどう変わるかを見る。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    kata_threshold = mo.ui.slider(0.01, 0.15, value=0.055, step=0.005, label="片仮名の比率のしきい値")
    kata_threshold
    return (kata_threshold,)


@app.cell(hide_code=True)
def _(
    author_color,
    df,
    genre,
    genre_symbol,
    kata_threshold,
    mo,
    np,
    plot_df,
    px,
):
    _kata = df["片仮名"].to_numpy()
    _pred = np.where(_kata > kata_threshold.value, "ライトノベル", "近代文学")
    _acc = np.mean(_pred == genre)
    genre_fig = px.scatter(
        plot_df, x="片仮名", y="文長mu", color="著者", symbol="区分", color_discrete_map=author_color,
        symbol_map=genre_symbol, hover_name="題名",
        labels={"片仮名": "片仮名の比率", "文長mu": "文長 μ"},
    )
    genre_fig.update_traces(marker=dict(size=7, opacity=0.75))
    genre_fig.add_vline(x=kata_threshold.value, line=dict(color="#D55E00", width=1.5, dash="dot"))
    genre_fig.update_layout(height=480, template="plotly_white", margin=dict(t=30, b=40))
    mo.vstack([
        mo.md(f"「片仮名 > {kata_threshold.value:.3f} ならライトノベル」の正解率: **{_acc:.3f}**"
              f"(誤り {int(np.sum(_pred != genre))} 作品)。基準線(多いほうを答え続ける)は {max(np.mean(genre == '近代文学'), np.mean(genre == 'ライトノベル')):.3f}。"),
        genre_fig,
    ])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    1列の質問1回で9割近くが分かれる。52列のランダムフォレストなら1.000になるが、
    上積みは残りの1割ぶんでしかない。**最も単純な規則を先に試す**(第11章)。

    ただし、ここでの「ライトノベル」は6シリーズ、しかも著者とシリーズが1対1に対応している。
    この分かれ方が「ジャンルの文体」なのか「この6シリーズの癖」なのかは、このデータだけでは決められない
    (第9章「グループの漏れ」、第11章「交絡」)。

    ## まとめ

    数える → 特徴にする → 距離を決める → まとめる → 落として眺める → 当てて測る。
    どの段階にも「そうしなくてもよかった選択」がある。標準化するか、どの列を使うか、
    どこで木を切るか、どう分割するか。本書は、その選択を変えたときに数字がどう動くかを
    実際に測りながら進む。このノートブックの各節の切り替えは、そのための最小限の実験である。
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
 
    """)
    return


if __name__ == "__main__":
    app.run()
