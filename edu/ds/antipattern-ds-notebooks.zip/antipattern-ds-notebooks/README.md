# 『アンチパターンで学ぶデータ分析』marimo教材

久保山哲二『アンチパターンで学ぶデータ分析 ── 作家の判別を題材に』の付属教材。
使い方は本書の付録Aを参照。

## ファイル

| ファイル | 内容(本書の章) |
|---|---|
| `01_style_map.py` | 次元削減による文体の地図、元の特徴空間との近傍の比較、入力文の表示(第3・4・6章) |
| `04_clustering.py` | k-meansの反復、初期値による違い、デンドログラムの切断(第5・6章) |
| `05_classification.py` | 分類器の予測確率と、判定のしきい値による誤分類の変化(第7・8章) |
| `06_leakage_and_pitfalls.py` | 特徴選択と標準化による漏洩、長編単位の分割、次元数による近傍の変化(第9章) |
| `public/features.csv` | 近代文学74作品の特徴量。ノートブックはこれを読む。移動しないこと |

ファイル名の番号は本書の章番号とは異なる。

## 実行

[uv](https://docs.astral.sh/uv/getting-started/installation/) を入れてから、
このフォルダで次を実行する。初回は必要なPythonとライブラリをダウンロードする。

```sh
uvx marimo run --sandbox 04_clustering.py    # 操作するだけ
uvx marimo edit --sandbox 04_clustering.py   # コードも編集する
```

## ライセンス

コードは MIT License、データ(`features.csv`)は CC BY 4.0。
近代文学の本文は青空文庫(https://www.aozora.gr.jp/)に拠る(本文は同梱していない)。

Copyright (c) 2026 Tetsuji Kuboyama
