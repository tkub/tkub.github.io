# 『アンチパターンで学ぶデータ分析』marimo教材

久保山哲二『アンチパターンで学ぶデータ分析 ── 作家の判別を題材に』の付属教材。
使い方は本書の付録Aを参照。

## ファイル

| ファイル | 内容(本書の章) |
|---|---|
| `00_from_text_to_authors.py` | 通し教材。生の文章を数えるところから、特徴の設計、距離、クラスタリング(デンドログラム・k-means)、PCA とバイプロット、交差検証、ジャンル判別まで、本書の順に追う(第2〜9・11章)。ライトノベルを含む134作品 |
| `01_style_map.py` | 次元削減による文体の地図、元の特徴空間との近傍の比較、入力文の表示(第3・4・6章) |
| `04_clustering.py` | k-meansの反復、初期値による違い、デンドログラムの切断(第5・6章) |
| `05_classification.py` | 分類器の予測確率と、判定のしきい値による誤分類の変化(第7・8章) |
| `06_leakage_and_pitfalls.py` | 特徴選択と標準化による漏洩、長編単位の分割、次元数による近傍の変化(第9章) |
| `public/features.csv` | 近代文学74作品の特徴量 |
| `public/features_all.csv` | 近代文学74作品+ライトノベル60区間の特徴量(`00` が読む) |
| `public/samples/` | `00` で実際に数える本文。青空文庫の『斜陽』『走れメロス』『紅玉』『並木』(奥付をそのまま残してある)と、Project Gutenberg の『赤毛のアン』 |

まず `00` を通して読み、個別の実験は `01`〜`06` で条件を変えて試す。
ファイル名の番号は本書の章番号とは異なる。`public/` はノートブックと同じ場所に置くこと。

## 実行

[uv](https://docs.astral.sh/uv/getting-started/installation/) を入れてから、
このフォルダで次を実行する。初回は必要なPythonとライブラリをダウンロードする。

```sh
uvx marimo run --sandbox --include-code 00_from_text_to_authors.py   # 読む(コードは折りたたみ)
uvx marimo edit --sandbox 00_from_text_to_authors.py                 # 編集もする
```

## ライセンス

コードは MIT License、特徴量のデータは CC BY 4.0。
近代文学の本文は青空文庫(https://www.aozora.gr.jp/)に拠り、再配布は同文庫の取り扱い規準に従う。
ライトノベルの本文は同梱していない。

Copyright (c) 2026 Tetsuji Kuboyama
