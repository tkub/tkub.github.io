# /// script
# requires-python = ">=3.12"
# dependencies = ["marimo>=0.24", "polars>=1.0", "numpy>=2.0", "scipy>=1.14", "scikit-learn>=1.5", "plotly>=5.24", "regex>=2024.9"]
# ///

import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _():
    import marimo as mo
    import numpy as np
    import polars as pl
    import plotly.graph_objects as go
    from sklearn.preprocessing import StandardScaler

    return StandardScaler, go, mo, np, pl


@app.cell(hide_code=True)
def _(mo, pl):
    df = pl.read_csv(str(mo.notebook_location() / "public" / "features.csv"))
    cols = [c for c in df.columns if c not in ("著者", "題名", "区分")]
    X = df.select(cols).to_numpy()
    y = df["著者"].to_numpy()
    titles = df["題名"].to_list()
    return X, cols, titles, y


@app.cell(hide_code=True)
def _(mo):
    mo.md("""
    # 境界を動かす、判断を変える
    第7・8章の授業用。2人の作家を2つの特徴で分ける。
    **見逃しを減らすと、誰を誤って拾うか。**
    曲面の高さは陽性側の作家であるとモデルが出した確率。しきい値の平面を下げると、陽性と判定する範囲が広がる。
    この検証データを見ながら特徴量やモデルを選ぶので、表示された正解率を未知データに対する性能として報告することはできない。最終評価には、これらの選択に使っていないデータが必要である。
    """)
    return


@app.cell(hide_code=True)
def _(cols, mo, y):
    positive = mo.ui.dropdown(sorted(set(y)), value="太宰治", label="陽性とする作家")
    negative = mo.ui.dropdown(sorted(set(y)), value="夏目漱石", label="もう1人")
    fx = mo.ui.dropdown(cols, value="は", label="横軸")
    fy = mo.ui.dropdown(cols, value="て", label="奥行きの軸")
    model = mo.ui.radio(
        ["ロジスティック回帰", "決定木", "kNN"],
        value="ロジスティック回帰",
        inline=True,
        label="モデル",
    )
    depth = mo.ui.slider(1, 8, value=3, label="木の深さ", show_value=True)
    neighbors = mo.ui.slider(1, 7, value=3, label="kNNの近傍数", show_value=True)
    regularization = mo.ui.slider(
        steps=[0.01, 0.1, 1, 10, 100],
        value=1,
        label="C(大きいほど弱い正則化)",
        show_value=True,
    )
    split_seed = mo.ui.slider(0, 19, value=0, label="分割の番号", show_value=True)
    threshold = mo.ui.slider(
        0.05, 0.95, step=0.05, value=0.5, label="陽性と答えるしきい値", show_value=True
    )
    mo.vstack(
        [
            mo.hstack([positive, negative, fx, fy], wrap=True, justify="start", gap=2),
            model,
            mo.hstack(
                [depth, neighbors, regularization], wrap=True, justify="start", gap=2
            ),
            mo.hstack([split_seed, threshold], wrap=True, justify="start", gap=2),
        ]
    )
    return (
        depth,
        fx,
        fy,
        model,
        negative,
        neighbors,
        positive,
        regularization,
        split_seed,
        threshold,
    )


@app.cell(hide_code=True)
def _(fx, fy, mo, negative, positive):
    mo.stop(positive.value == negative.value, mo.md("異なる2人の作家を選ぶ。"))
    mo.stop(fx.value == fy.value, mo.md("異なる2つの特徴を選ぶ。"))
    valid = True
    return (valid,)


@app.cell(hide_code=True)
def _(X, cols, fx, fy, negative, np, positive, split_seed, titles, valid, y):
    _guard = valid
    from sklearn.model_selection import train_test_split

    _mask = np.isin(y, [positive.value, negative.value])
    B = X[_mask][:, [cols.index(fx.value), cols.index(fy.value)]]
    binary = (y[_mask] == positive.value).astype(int)
    work_names = np.array(titles)[_mask]
    train, validation = train_test_split(
        np.arange(len(B)),
        test_size=0.35,
        stratify=binary,
        random_state=split_seed.value,
    )
    return B, binary, train, validation, work_names


@app.cell(hide_code=True)
def _(
    B,
    StandardScaler,
    binary,
    depth,
    model,
    neighbors,
    regularization,
    train,
):
    from sklearn.pipeline import make_pipeline
    from sklearn.linear_model import LogisticRegression
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.neighbors import KNeighborsClassifier

    if model.value == "決定木":
        classifier = DecisionTreeClassifier(max_depth=depth.value, random_state=0)
    elif model.value == "kNN":
        classifier = make_pipeline(
            StandardScaler(), KNeighborsClassifier(min(neighbors.value, len(train)))
        )
    else:
        classifier = make_pipeline(
            StandardScaler(), LogisticRegression(C=regularization.value, max_iter=2000)
        )
    classifier.fit(B[train], binary[train])
    probabilities = classifier.predict_proba(B)[:, 1]
    return classifier, probabilities


@app.cell(hide_code=True)
def _(
    B,
    binary,
    classifier,
    fx,
    fy,
    go,
    np,
    positive,
    probabilities,
    threshold,
    train,
    validation,
    work_names,
):
    _span = np.ptp(B, axis=0)
    _pad = np.where(_span > 0, _span * 0.08, 0.01)
    _axis0 = np.linspace(B[:, 0].min() - _pad[0], B[:, 0].max() + _pad[0], 65)
    _axis1 = np.linspace(B[:, 1].min() - _pad[1], B[:, 1].max() + _pad[1], 65)
    grid_x, grid_y = np.meshgrid(_axis0, _axis1)
    response = classifier.predict_proba(np.c_[grid_x.ravel(), grid_y.ravel()])[
        :, 1
    ].reshape(grid_x.shape)
    surface = go.Figure(
        go.Surface(
            x=grid_x,
            y=grid_y,
            z=response,
            cmin=0,
            cmax=1,
            colorscale="Cividis",
            opacity=0.75,
            colorbar=dict(title="P(陽性)"),
            name="予測確率",
        )
    )
    surface.add_trace(
        go.Surface(
            x=grid_x,
            y=grid_y,
            z=np.full_like(response, threshold.value),
            colorscale=[[0, "#D55E00"], [1, "#D55E00"]],
            opacity=0.2,
            showscale=False,
            hoverinfo="skip",
            name="しきい値",
        )
    )
    for _ids, _name, _symbol in [
        (train, "訓練", "circle"),
        (validation, "検証", "diamond"),
    ]:
        surface.add_trace(
            go.Scatter3d(
                x=B[_ids, 0],
                y=B[_ids, 1],
                z=binary[_ids],
                mode="markers",
                name=_name,
                marker=dict(
                    size=6,
                    symbol=_symbol,
                    color=binary[_ids],
                    cmin=0,
                    cmax=1,
                    colorscale="Cividis",
                    line=dict(width=1, color="#222"),
                ),
                text=work_names[_ids],
                customdata=probabilities[_ids],
                hovertemplate="%{text}<br>正解=%{z}<br>予測確率=%{customdata:.3f}<extra>"
                + _name
                + "</extra>",
            )
        )
    surface.update_layout(
        height=600,
        template="plotly_white",
        scene=dict(
            xaxis_title=fx.value,
            yaxis_title=fy.value,
            zaxis=dict(title="予測確率 / 正解0・1", range=[-0.05, 1.05]),
        ),
        legend=dict(orientation="h", y=1.08, x=0),
        uirevision=f"{positive.value}-{fx.value}-{fy.value}",
        margin=dict(l=0, r=0, b=0, t=20),
    )
    surface
    return grid_x, grid_y, response


@app.cell(hide_code=True)
def _(
    binary,
    mo,
    np,
    pl,
    probabilities,
    threshold,
    train,
    validation,
    work_names,
):
    from sklearn.metrics import (
        confusion_matrix,
        precision_score,
        recall_score,
        brier_score_loss,
    )

    predicted = (probabilities >= threshold.value).astype(int)
    truth = binary[validation]
    answers = predicted[validation]
    cm = confusion_matrix(truth, answers, labels=[0, 1])
    precision = (
        precision_score(truth, answers, zero_division=0) if answers.sum() else None
    )
    recall = recall_score(truth, answers, zero_division=0)
    _p = "未定義(陽性の予測0件)" if precision is None else f"{precision:.3f}"
    mo.output.append(
        mo.md(
            f"訓練 **{len(train)}作品** / 検証 **{len(validation)}作品**\n\n正解率 **{np.mean(answers == truth):.3f}** / 適合率 **{_p}** / 再現率 **{recall:.3f}** / Brier **{brier_score_loss(truth, probabilities[validation]):.3f}**\n\n陽性を見逃した作品 **{cm[1, 0]}件** / 陰性を陽性と答えた作品 **{cm[0, 1]}件**。しきい値を変えても予測確率とBrierは変わらない。"
        )
    )
    result_table = pl.DataFrame(
        {
            "題名": work_names[validation],
            "正解(陽性=1)": truth,
            "陽性の予測確率": probabilities[validation],
            "判定": answers,
            "誤り": answers != truth,
        }
    )
    return (result_table,)


@app.cell(hide_code=True)
def _(
    B,
    binary,
    fx,
    fy,
    go,
    grid_x,
    grid_y,
    mo,
    pl,
    response,
    result_table,
    threshold,
    validation,
    work_names,
):
    # 真上からの断面も残す。3Dで隠れた作品の位置を確認する。
    section = go.Figure(
        go.Contour(
            x=grid_x[0],
            y=grid_y[:, 0],
            z=response,
            zmin=0,
            zmax=1,
            colorscale="Cividis",
            showscale=False,
            contours=dict(
                start=threshold.value, end=threshold.value, size=1, coloring="lines"
            ),
            line=dict(color="#D55E00", width=3),
        )
    )
    section.add_trace(
        go.Scatter(
            x=B[validation, 0],
            y=B[validation, 1],
            mode="markers",
            text=work_names[validation],
            marker=dict(
                size=10,
                color=binary[validation],
                cmin=0,
                cmax=1,
                colorscale="Cividis",
                symbol="diamond",
                line=dict(color="#222", width=1),
            ),
            showlegend=False,
        )
    )
    section.update_layout(
        height=330,
        template="plotly_white",
        title="しきい値の境界と検証作品",
        xaxis_title=fx.value,
        yaxis_title=fy.value,
        margin=dict(t=45, b=40),
    )
    mo.vstack(
        [
            section,
            mo.ui.table(
                result_table.with_columns(pl.col("陽性の予測確率").round(3)),
                selection=None,
            ),
            mo.md(
                "分割を変えて、同じしきい値が同じ誤り方をするか確かめる。曲面は2列だけのモデルの出力であり、作品のない場所にも描かれている。高さが0.9でも、実際に9割当たることはまだ確かめていない。"
            ),
        ]
    )
    return


if __name__ == "__main__":
    app.run()
