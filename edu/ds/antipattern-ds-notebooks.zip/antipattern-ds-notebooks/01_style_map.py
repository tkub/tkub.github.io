# /// script
# requires-python = ">=3.12"
# dependencies = ["marimo>=0.24", "polars>=1.0", "numpy>=2.0", "scipy>=1.14", "scikit-learn>=1.5", "plotly>=5.24", "regex>=2024.9"]
# ///

import marimo

__generated_with = "0.24.0"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _():
    import marimo as mo
    import numpy as np
    import polars as pl
    import plotly.express as px
    import plotly.graph_objects as go
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    return PCA, StandardScaler, go, mo, np, pl, px


@app.cell(hide_code=True)
def _(mo, pl):
    df = pl.read_csv(str(mo.notebook_location() / "public" / "features.csv"))
    cols = [c for c in df.columns if c not in ("著者", "題名", "区分")]
    X = df.select(cols).to_numpy()
    y = df["著者"].to_numpy()
    titles = df["題名"].to_list()
    colors = dict(
        zip(
            sorted(set(y)),
            [
                "#0072B2",
                "#D55E00",
                "#009E73",
                "#CC79A7",
                "#E69F00",
                "#56B4E9",
                "#332288",
                "#882255",
            ],
        )
    )
    return X, colors, cols, titles, y


@app.cell(hide_code=True)
def _(mo):
    mo.md("""
    # 文体の地図と、地図に残らない距離
    第3・4・6章の授業用。74作品の52列を2次元・3次元に写す。
    **地図で隣に見える作品は、元の52列でも近いか。**
    作品を1つ選び、赤い線で結んだ近傍を確かめる。著者名は色にだけ使い、配置には使わない。
    """)
    return


@app.cell(hide_code=True)
def _(mo, titles):
    method = mo.ui.dropdown(
        ["PCA", "MDS", "t-SNE", "Isomap"], value="PCA", label="手法"
    )
    dimensions = mo.ui.radio(
        ["2D", "3D"], value="3D", inline=True, label="表示する次元"
    )
    scale = mo.ui.switch(value=True, label="52列を標準化")
    perplexity = mo.ui.slider(
        5, 40, step=5, value=15, label="t-SNEのperplexity", show_value=True
    )
    seed = mo.ui.slider(0, 9, value=0, label="MDS・t-SNEの乱数", show_value=True)
    focus = mo.ui.dropdown(
        {t: i for i, t in enumerate(titles)}, value=titles[0], label="基準にする作品"
    )
    compress = mo.ui.slider(
        0, 1, step=0.1, value=1, label="PCAの第3軸を残す割合(3Dのみ)", show_value=True
    )
    mo.vstack(
        [
            mo.hstack([method, dimensions, scale], wrap=True, justify="start", gap=2),
            mo.hstack([perplexity, seed, compress], wrap=True, justify="start", gap=2),
            focus,
        ]
    )
    return compress, dimensions, focus, method, perplexity, scale, seed


@app.cell(hide_code=True)
def _(PCA, StandardScaler, X, dimensions, method, perplexity, scale, seed):
    from sklearn.manifold import MDS, TSNE, Isomap, trustworthiness
    from sklearn.metrics import pairwise_distances

    A = StandardScaler().fit_transform(X) if scale.value else X.copy()
    dim = 3 if dimensions.value == "3D" else 2
    if method.value == "PCA":
        embedding = PCA(n_components=dim).fit(A)
        coordinates = embedding.transform(A)
    elif method.value == "MDS":
        embedding = MDS(
            n_components=dim,
            random_state=seed.value,
            n_init=2,
            normalized_stress="auto",
        )
        coordinates = embedding.fit_transform(A)
    elif method.value == "t-SNE":
        embedding = TSNE(
            n_components=dim,
            random_state=seed.value,
            perplexity=perplexity.value,
            init="pca",
        )
        coordinates = embedding.fit_transform(A)
    else:
        embedding = Isomap(n_components=dim, n_neighbors=10)
        coordinates = embedding.fit_transform(A)
    return A, coordinates, dim, embedding, pairwise_distances, trustworthiness


@app.cell(hide_code=True)
def _(
    A,
    compress,
    coordinates,
    dim,
    embedding,
    focus,
    method,
    np,
    pairwise_distances,
    trustworthiness,
):
    Z = coordinates.copy()
    if method.value == "PCA" and dim == 3:
        Z[:, 2] *= compress.value
    D = pairwise_distances(A)
    D_map = pairwise_distances(Z)
    np.fill_diagonal(D, np.inf)
    np.fill_diagonal(D_map, np.inf)
    near = np.argsort(D[focus.value])[:5]
    near_map = np.argsort(D_map[focus.value])[:5]
    overlap = len(set(near) & set(near_map))
    trust = trustworthiness(A, Z, n_neighbors=5)
    loss = None
    if method.value == "PCA":
        loss = float(
            np.sum((A - embedding.inverse_transform(Z)) ** 2)
            / np.sum((A - A.mean(axis=0)) ** 2)
        )
    return D, Z, loss, near, near_map, overlap, trust


@app.cell(hide_code=True)
def _(Z, colors, coordinates, dim, focus, go, method, near, np, px, titles, y):
    _kwargs = dict(
        x=Z[:, 0],
        y=Z[:, 1],
        color=y,
        hover_name=titles,
        color_discrete_map=colors,
        labels={"color": "著者", "x": "第1軸", "y": "第2軸", "z": "第3軸"},
    )
    chart = px.scatter_3d(**_kwargs, z=Z[:, 2]) if dim == 3 else px.scatter(**_kwargs)
    _segments = np.full((15, dim), np.nan)
    _segments[::3] = Z[focus.value]
    _segments[1::3] = Z[near]
    _line = dict(
        x=_segments[:, 0],
        y=_segments[:, 1],
        mode="lines",
        name="元の距離で近い5作品",
        line=dict(color="#D55E00", width=4),
        hoverinfo="skip",
    )
    _mark = dict(
        x=[Z[focus.value, 0]],
        y=[Z[focus.value, 1]],
        mode="markers",
        name="基準作品",
        marker=dict(size=10, color="#111", symbol="diamond"),
    )
    if dim == 3:
        chart.add_trace(go.Scatter3d(**_line, z=_segments[:, 2]))
        chart.add_trace(go.Scatter3d(**_mark, z=[Z[focus.value, 2]]))
        _ranges = [
            [float(coordinates[:, j].min()) - 0.5, float(coordinates[:, j].max()) + 0.5]
            for j in range(3)
        ]
        chart.update_layout(
            scene=dict(
                aspectmode="data",
                xaxis=dict(range=_ranges[0]),
                yaxis=dict(range=_ranges[1]),
                zaxis=dict(range=_ranges[2]),
            )
        )
    else:
        chart.add_trace(go.Scatter(**_line))
        chart.add_trace(go.Scatter(**_mark))
        chart.update_yaxes(scaleanchor="x", scaleratio=1)
    chart.update_traces(marker_size=4, selector=dict(mode="markers"))
    chart.data[-1].marker.size = 10
    chart.update_layout(
        height=610,
        template="plotly_white",
        uirevision=f"map-{method.value}-{dim}",
        margin=dict(l=0, r=0, t=20, b=0),
    )
    chart
    return


@app.cell(hide_code=True)
def _(D, focus, loss, mo, near, near_map, overlap, pl, titles, trust, y):
    _loss = "" if loss is None else f" / PCAの再構成で失われる平方和 **{loss:.1%}**"
    _lead = mo.md(
        f"元の距離と地図で共通する近傍 **{overlap}/5作品** / Trustworthiness(k=5) **{trust:.3f}**{_loss}\n\nTrustworthinessは地図で近づいた点が元の空間でも近いかを見る指標(1に近いほどよい)。この値が高くても、遠い点どうしの距離や点群の広がりが元の空間と同じ割合で描かれているとは限らない。PCAの第3軸を縮め、近傍と再構成誤差が変わるか確かめる。"
    )
    neighbor_table = pl.DataFrame(
        {
            "順位": list(range(1, 6)),
            "元の距離で近い作品": [titles[i] for i in near],
            "著者": [y[i] for i in near],
            "元の距離": D[focus.value, near],
            "地図で近い作品": [titles[i] for i in near_map],
        }
    )
    mo.vstack(
        [
            _lead,
            mo.ui.table(
                neighbor_table.with_columns(pl.col("元の距離").round(3)), selection=None
            ),
        ]
    )
    return


@app.cell(hide_code=True)
def _(mo):
    _lead = mo.md(
        "## 自分の文章を同じ地図に置く\n    ここからは基準を固定する。74作品だけで標準化とPCAを学習し、入力した文章を変換する。\n    上の手法の選択とは別に、3次元PCAで比べる。**同じ内容を、文の切り方だけ変えたらどこへ動くか。**\n    本文だけを貼り付ける。題名・著者名・奥付は含めない。文長と読点の比率は短い文章ほど不安定になる。"
    )
    user_text = mo.ui.text_area(
        value="\n中原を指して\n\n一\n\n蜀の大軍は、※陽（陝西省・※県、漢中の西）まで進んで出た。ここまで来た時、\n「魏は関西の精兵を以て、長安（陝西省・西安）に布陣し、大本営をそこにおいた」\nという情報が的確になった。\nいわゆる天下の嶮、蜀の桟道をこえて、ここまで出てくるだけでも、軍馬は一応疲れる。孔明は、※陽に着くと、\n「ここには、亡き馬超の墳がある。いまわが蜀軍の北伐に遭うて、地下白骨の自己を嘆じ、なつかしくも思っているだろう。祭を営んでやるがよい」\nと、馬岱を祭主に命じ、あわせてその期間に、兵馬を休ませていた。\n一日、魏延が説いた。\n「丞相。それがしに、五千騎おかし下さい。こんなことをしている間に、長安を潰滅してみせます」\n「策に依ってはだが……？」\n「ここと長安の間は、長駆すれば十日で達する距離です。もしお許しあれば、秦嶺を越え、子午谷を渡り、虚を衝いて、敵を混乱に陥れ、彼の糧食を焼き払いましょう。——丞相は斜谷から進まれ、咸陽へ伸びて出られたら、魏の夏侯楙などは、一鼓して破り得るものと信じますが」\n「いかんなあ」\n孔明は取り上げない。雑談のように軽く聞き流して、\n「もし敵に智のある者がいれば、兵をまわして、山際の切所を断つにきまっている。そのときご辺の五千の兵は、一人も生きては帰れないだろう」\n「でも、本道を進めば、魏の大軍に対して、どれほど多くの損害を出すか知れますまい」\n孔明はうなずいた。その通りであると肯定しているものの如くである。そして彼は彼の考えどおり軍を進ませた。隴右の大路へ出でて正攻法を取ったものである。\nこれは、魏の予想に反した。孔明はよく智略を用いるという先入観から、さだめし奇道を取ってくるだろうと信じて、ほかの間道へも兵力を分け、大いに備えていたところが、意外にも蜀軍は堂々と直進して来た。\n「まず、西※の兵に、一当て当てさせてみよう」\n夏侯楙は、韓徳を呼んだ。これはこんど魏軍が長安を本営としてから、西涼の※兵八万騎をひきいて、なにか一手勲せんと、参加した外郭軍の大将だった。\n「鳳鳴山まで出で、蜀の先鋒を防げ。この一戦は、魏蜀の第一会戦だから、以後の士気にもかかわるぞ。充分、功名を立てるがいい」\n夏侯楙に励まされて韓徳は勇んで立った。\n彼に四人の子がある。韓瑛、韓瑤、韓瓊、韓※、みな弓馬に達し、力衆に超えていた。\n「八万の強兵、四人の偉児。もって、蜀軍にひと泡吹かすに足るだろう」\n自負満々、彼は戦場へ臨んだが、なんぞ知らん、これは夏侯楙が、なるべく魏直系の兵を傷めずに、蜀の先鋒へまず当てさせた試しに乗ったものとはさとらなかった。\n望みどおり蜀軍の先鋒と、鳳鳴山の下で出会ったが、その第一会戦に、韓徳は四人の子を亡ってしまった。\nそのあいては、蜀の老将趙雲であった。\n長男の韓瑛が、\n「趙雲を見た」\nと、軍の中で告げたので、四子を伴ってその首をと、追撃してまわるうち、やがて趙雲のほうから駒をかえしてきて、\n「豎子。望むのは、これか」\nと、一槍の下に韓瑛を突き殺した。\n韓瓊、韓瑤、韓※が三方から、\n「老いぼれ」\nと、挟撃したが、またたく間に、韓瓊、韓※も討たれ、趙雲は悠々引揚げて行った。\nひとり残った韓瑤は、急に追いかけて、そのうしろから斬りつけたが、趙雲は身をそばめて、韓瑤を馬の鞍へひき寄せ、\n「ああ、殺すも飽いた」\nと、こんどは、引っつかんだまま、生捕って帰ってしまった。\n父韓徳は、心も萎え、大敗して、長安へ逃げくずれた。\n\n二\n\n※芝は、きょうの勝ち戦を賀したのち、趙雲に云った。\n「お齢もすでに七旬を越されているのに、きょうの戦場で三人の若い大将を討ち、一人の大将を生擒ってこられるなど、まったく壮者も及ばぬお働き、実に驚き入りました。……これでは成都を立つ前に、丞相が留守へ廻そうとしたのに対して、ご不満をのべられたのも無理ではありませんな」\n趙雲は快然と笑った。\n「いや、その意地もあるので、きょうは少し働いた。しかしこんな程度を功として安んじる趙雲ではない。まだまだ腕に年は老らないつもりだ」\n※芝は、つぶさに戦況を書いて、まず序戦の吉報を、後陣の孔明へ急送しておいた。\nそれに反して、魏の士気はそそけ立った。わけて都督夏侯楙は、\n「韓徳が一敗地にやぶれたのを見ても、これはやや敵を軽んじ過ぎた。大挙して、彼の先鋒を打ち挫かぬ分",
        rows=7,
        full_width=True,
        label="比較する本文",
    ).form(submit_button_label="地図に置く")
    user_metric = mo.ui.radio(
        ["ユークリッド", "コサイン"],
        value="ユークリッド",
        inline=True,
        label="近さの測り方(標準化した52列)",
    )
    mo.vstack([_lead, mo.vstack([user_text, user_metric])])
    return user_metric, user_text


@app.cell(hide_code=True)
def _():
    import regex
    import re
    from collections import Counter

    # 配布CSVを作ったコーパスで観測した文字集合。低頻度列を落とす前の分母。
    comma_vocabulary = [
        "ぁ",
        "あ",
        "い",
        "う",
        "ぇ",
        "え",
        "お",
        "か",
        "が",
        "き",
        "ぎ",
        "く",
        "ぐ",
        "け",
        "げ",
        "こ",
        "ご",
        "さ",
        "ざ",
        "し",
        "じ",
        "す",
        "ず",
        "せ",
        "ぜ",
        "そ",
        "ぞ",
        "た",
        "だ",
        "ち",
        "っ",
        "つ",
        "づ",
        "て",
        "で",
        "と",
        "ど",
        "な",
        "に",
        "ぬ",
        "ね",
        "の",
        "は",
        "ば",
        "ぱ",
        "ひ",
        "び",
        "ふ",
        "ぶ",
        "へ",
        "べ",
        "ほ",
        "ぼ",
        "ま",
        "み",
        "む",
        "め",
        "も",
        "ゃ",
        "や",
        "ゆ",
        "ょ",
        "よ",
        "ら",
        "り",
        "る",
        "れ",
        "ろ",
        "わ",
        "ゐ",
        "ゑ",
        "を",
        "ん",
    ]

    def extract_input(text, columns):
        body = "\n".join(line.strip().replace("　", "") for line in text.splitlines())
        body = re.sub(r"《[^》]+》", "", body.replace("｜", ""))
        body = re.sub(r"［＃[^］]+］", "", body)
        body = re.sub(r"[*\-|｜]+", "", body)
        counts = [
            len(regex.findall(p, body))
            for p in [r"\p{Hiragana}", r"\p{Katakana}", r"\p{Han}"]
        ]
        noise_pattern = r"[\s、。！？（）「」『』〈〉]+"
        lengths = [
            len(regex.sub(noise_pattern, "", s))
            for s in re.split(r"[。！？]", body)
            if s.strip()
        ]
        lengths = [n for n in lengths if n > 0]
        comma_counts = Counter(regex.findall(r"(\p{Hiragana})、", body))
        total_comma = sum(comma_counts[c] for c in comma_vocabulary)
        if not sum(counts) or len(lengths) < 3 or total_comma < 1:
            return None, len(lengths), total_comma
        import numpy as np

        logs = np.log(lengths)
        row = dict(zip(["平仮名", "片仮名", "漢字"], np.array(counts) / sum(counts)))
        row.update({"文長mu": logs.mean(), "文長sigma": logs.std()})
        row.update({c: comma_counts[c] / total_comma for c in columns[5:]})
        return np.array([row[c] for c in columns]), len(lengths), total_comma

    return (extract_input,)


@app.cell(hide_code=True)
def _(PCA, StandardScaler, X):
    reference_scaler = StandardScaler().fit(X)
    reference_X = reference_scaler.transform(X)
    reference_pca = PCA(n_components=3).fit(reference_X)
    reference_Z = reference_pca.transform(reference_X)
    return reference_X, reference_Z, reference_pca, reference_scaler


@app.cell(hide_code=True)
def _(cols, extract_input, mo, user_text):
    mo.stop(user_text.value is None, mo.md("本文を確かめて「地図に置く」を押す。"))
    input_vector, sentence_count, comma_count = extract_input(user_text.value, cols)
    mo.stop(
        input_vector is None,
        mo.md("字種を数えられる本文、3文以上、平仮名直後の読点が1つ以上必要である。"),
    )
    mo.md(
        f"文 **{sentence_count}** / 分母に数えた読点 **{comma_count}**。"
        + (
            "読点が30個未満なので、1個の違いでも比率が大きく動く。"
            if comma_count < 30
            else "件数だけで推定の安定性が保証されるわけではない。"
        )
    )
    return (input_vector,)


@app.cell(hide_code=True)
def _(
    colors,
    go,
    input_vector,
    mo,
    np,
    pairwise_distances,
    pl,
    px,
    reference_X,
    reference_Z,
    reference_pca,
    reference_scaler,
    titles,
    user_metric,
    y,
):
    u = reference_scaler.transform(input_vector.reshape(1, -1))
    uZ = reference_pca.transform(u)
    input_distances = pairwise_distances(
        u,
        reference_X,
        metric="euclidean" if user_metric.value == "ユークリッド" else "cosine",
    )[0]
    input_near = np.argsort(input_distances)[:5]
    input_chart = px.scatter_3d(
        x=reference_Z[:, 0],
        y=reference_Z[:, 1],
        z=reference_Z[:, 2],
        color=y,
        hover_name=titles,
        color_discrete_map=colors,
        labels={"color": "著者", "x": "PC1", "y": "PC2", "z": "PC3"},
    )
    input_chart.add_trace(
        go.Scatter3d(
            x=uZ[:, 0],
            y=uZ[:, 1],
            z=uZ[:, 2],
            mode="markers",
            name="入力した文章",
            marker=dict(size=11, symbol="diamond", color="#111"),
        )
    )
    input_chart.update_traces(marker_size=4, selector=dict(mode="markers"))
    input_chart.data[-1].marker.size = 10
    input_chart.update_layout(
        height=540,
        template="plotly_white",
        scene=dict(aspectmode="data"),
        uirevision="input-camera",
        margin=dict(t=20, l=0, r=0, b=0),
    )
    mo.vstack(
        [
            input_chart,
            mo.ui.table(
                pl.DataFrame(
                    {
                        "近い作品": [titles[i] for i in input_near],
                        "著者": [y[i] for i in input_near],
                        "52列での距離": input_distances[input_near],
                    }
                ),
                selection=None,
            ),
            mo.md(
                "順位は入力文と74作品の特徴ベクトル間の距離が小さい順に並べたものである。著者の認定や、文体の一致を示す検定ではない。字種や句読点の特徴にも、時代・題材・文章の長さの影響は残る。"
            ),
        ]
    )
    return


if __name__ == "__main__":
    app.run()
