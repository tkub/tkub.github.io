#!/usr/bin/env python3
"""examples/ のファイルを機械的に検査する。

検査は9項目ある。6・7 は本書の .tex を、9 は main.toc を読むので、
リポジトリで実行したときだけ動く。配布 zip では自動的に飛ばす。

  1. すべての .ttl が Turtle として妥当か
  2. 使っている rico: 名が RiC-O 1.1 に実在するか
  3. 使っているプロパティが定義域・値域に反していないか
  4. queries.rq の全問い合わせが実行でき、期待した件数を返すか
  5. SHACL が期待した違反だけを報告するか(語彙を渡す場合と渡さない場合)
  6. 本文の Turtle listing と examples/ の中身が食い違っていないか
  7. 本文の全 Turtle listing が構文として妥当で、定義域・値域に反していないか
  8. 推論が要る問い合わせが、推論を入れたときに答えを返すか
  9. コメントに手書きした節番号が本書に実在するか(-v で見出しも印字)

必要なもの:
  pip install rdflib pyshacl owlrl

RiC-O 1.1 の RDF と CSV を読む。リポジトリなら sources/RiC-O/、
配布 zip なら同梱の ric-o/ を自動で使う。

実行:
  リポジトリ  python3 examples/check.py   (book-ric のルートから)
  配布 zip    python3 check.py            (展開したディレクトリで)
"""

import csv
import re
import sys
from pathlib import Path

from rdflib import Graph, RDF, RDFS, OWL, URIRef
from rdflib.namespace import Namespace

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
RICO = Namespace("https://www.ica.org/standards/RiC/ontology#")

# RiC-O の置き場所。リポジトリと配布 zip の両方に対応する。
SRC = next((d for d in (REPO / "sources" / "RiC-O", HERE / "ric-o")
            if (d / "RiC-O_1-1.rdf").exists()), REPO / "sources" / "RiC-O")

# 本書の .tex があるか。なければ検査6・7 は飛ばす。
CHAPTERS = sorted(REPO.glob("ch0*.tex"))
HAS_TEX = bool(CHAPTERS)
if HAS_TEX and (REPO / "appendix.tex").exists():
    CHAPTERS.append(REPO / "appendix.tex")

DATA_FILES = ["fonds-p83.ttl", "murakata.ttl", "family.ttl",
              "disposition.ttl", "shacl-data.ttl"]

# 本文が同じ名前を別の意味で使っている箇所。ファイル側では改名した。
# (本文 §4.3.1 の ex:s1 は §7.4.2 の ex:s1 とは別物である)
RENAMES = {
    "ch04.tex": {"https://archives.example.jp/s1": "https://archives.example.jp/series1950s"},
}

# 問い合わせ番号 -> 期待件数。推論なしの素の rdflib で実行した場合の値。
# None は「推論が要るので0件が正しい」ことを示す。
EXPECTED_ROWS = {
    1: 0,    # includesTransitive は推論で導かれる
    2: 5,    # s1, s2, f112, series1950s, r1
    3: 1,
    4: 2,    # 保健福祉部, 健康福祉部
    5: 5,
    6: 2,    # 山田源右衛門の書簡(1868)と日記(1885)
    7: 1,
    8: 1,
    9: 3,    # A-12(廃棄), B-07(移管), C-03(廃棄)
    10: 1,   # C-03 の廃棄だけ同意が書かれていない
    11: 1,
    12: 0,   # hasOrHadInstantiation は下位プロパティからの推論
    13: 0,   # hasAncestor は3段の推論で導かれる
    14: 2,   # 曽祖父の書簡と日記
}

# 「[推論]」と注記した問い合わせが、推論を入れたときに返すべき件数。
# 0 が正しいことだけを確かめても、問い合わせが壊れていても気づけない。
EXPECTED_ROWS_INFERRED = {
    1: 1,    # ex:r1(directlyIncludes の連鎖 + 推移性)
    12: 2,   # ex:r45 のアナログ/デジタル具現化
    13: 2,   # 曽祖父の書簡と日記(逆 + 下位 + 推移の3段)
}

fails = []


def fail(msg):
    fails.append(msg)
    print("  NG  " + msg)


def ok(msg):
    print("  ok  " + msg)


# ---------------------------------------------------------------------
# 1. Turtle のパース
# ---------------------------------------------------------------------
print("[1] Turtle のパース")
graphs = {}
for name in DATA_FILES + ["shapes.ttl"]:
    p = HERE / name
    g = Graph()
    try:
        g.parse(p, format="turtle")
        graphs[name] = g
        ok(f"{name}: {len(g)} トリプル")
    except Exception as e:
        fail(f"{name}: パース失敗 {e}")

# ---------------------------------------------------------------------
# 2. rico: 名の実在確認
# ---------------------------------------------------------------------
print("[2] rico: 名の実在確認(RiC-O 1.1 の CSV 一覧に照合)")
known = set()
for f in ["RiC-O_1-1_list-of-object-properties.csv",
          "RiC-O_1-1_list-of-datatype-properties.csv",
          "RiC-O_1-1_list-of-classes.csv"]:
    path = SRC / f
    if not path.exists():
        fail(f"{f} が見つからない({SRC})")
        continue
    for row in csv.reader(open(path)):
        if row and row[0].startswith("rico:"):
            known.add(row[0][5:])
if known:
    for name in DATA_FILES + ["shapes.ttl", "queries.rq"]:
        used = set(re.findall(r"\brico:([A-Za-z0-9_]+)", (HERE / name).read_text()))
        unknown = sorted(used - known)
        if unknown:
            fail(f"{name}: RiC-O にない名前 {unknown}")
        else:
            ok(f"{name}: {len(used)} 個すべて実在")

# ---------------------------------------------------------------------
# 3. 定義域・値域の照合
# ---------------------------------------------------------------------
print("[3] 定義域・値域の照合(RDF 本体を読んで推論なしで検査)")
onto_path = SRC / "RiC-O_1-1.rdf"
onto = Graph()
if onto_path.exists():
    onto.parse(onto_path)
else:
    fail(f"{onto_path} が見つからない")


def superclasses(g, cls, seen=None):
    seen = seen or set()
    if cls in seen:
        return seen
    seen.add(cls)
    for sup in g.objects(cls, RDFS.subClassOf):
        if isinstance(sup, URIRef):
            superclasses(g, sup, seen)
    return seen


if len(onto):
    # union の定義域・値域を展開する
    def class_list(g, node):
        if node is None:
            return set()
        if (node, OWL.unionOf, None) in g:
            out = set()
            for lst in g.objects(node, OWL.unionOf):
                out |= set(g.items(lst))
            return out
        return {node}

    dom, rng = {}, {}
    for p in set(onto.subjects(RDFS.domain, None)) | set(onto.subjects(RDFS.range, None)):
        d = set()
        for o in onto.objects(p, RDFS.domain):
            d |= class_list(onto, o)
        r = set()
        for o in onto.objects(p, RDFS.range):
            r |= class_list(onto, o)
        if d:
            dom[p] = d
        if r:
            rng[p] = r

    # shacl-data.ttl は意図的に誤りを含むので、この検査からは外す
    data = Graph()
    for name in ["fonds-p83.ttl", "murakata.ttl", "family.ttl", "disposition.ttl"]:
        data += graphs.get(name, Graph())
    types = {}
    for s, o in data.subject_objects(RDF.type):
        types.setdefault(s, set()).add(o)

    def conforms(node, allowed):
        if node not in types:
            return None            # 型が書かれていないものは判定しない
        for t in types[node]:
            if superclasses(onto, t) & allowed:
                return True
        return False

    problems = 0
    for s, p, o in data:
        if not str(p).startswith(str(RICO)):
            continue
        if p in dom and conforms(s, dom[p]) is False:
            fail(f"定義域違反: {s.n3(data.namespace_manager)} "
                 f"{p.n3(data.namespace_manager)} (許容: "
                 f"{sorted(c.split('#')[-1] for c in map(str, dom[p]))})")
            problems += 1
        if p in rng and isinstance(o, URIRef) and conforms(o, rng[p]) is False:
            fail(f"値域違反: {p.n3(data.namespace_manager)} -> "
                 f"{o.n3(data.namespace_manager)} (許容: "
                 f"{sorted(c.split('#')[-1] for c in map(str, rng[p]))})")
            problems += 1
    if problems == 0:
        ok(f"定義域・値域の違反なし({len(data)} トリプルを検査)")

# ---------------------------------------------------------------------
# 4. queries.rq
# ---------------------------------------------------------------------
print("[4] queries.rq の実行")
data = Graph()
for name in ["fonds-p83.ttl", "family.ttl", "disposition.ttl"]:
    data += graphs.get(name, Graph())

text = (HERE / "queries.rq").read_text()
blocks = re.split(r"^### ", text, flags=re.M)[1:]
for block in blocks:
    head, _, body = block.partition("\n")
    num = int(re.match(r"(\d+)\.", head).group(1))
    try:
        res = data.query(body)
        n = len(list(res))
    except Exception as e:
        fail(f"問い合わせ {num} が実行できない: {e}")
        continue
    exp = EXPECTED_ROWS.get(num)
    if exp is None:
        ok(f"問い合わせ {num}: {n} 件(期待値未設定)")
    elif n == exp:
        ok(f"問い合わせ {num}: {n} 件 --- {head.strip()}")
    else:
        fail(f"問い合わせ {num}: {n} 件(期待 {exp} 件)--- {head.strip()}")

# ---------------------------------------------------------------------
# 5. SHACL
# ---------------------------------------------------------------------
print("[5] SHACL の検証")
try:
    from pyshacl import validate
except ImportError:
    fail("pyshacl が入っていない(pip install pyshacl)")
    validate = None

if validate is not None:
    shapes = graphs["shapes.ttl"]

    # (a) データだけを渡した場合 --- 第8章の注意ボックスの落とし穴
    conforms, results, _ = validate(graphs["shacl-data.ttl"], shacl_graph=shapes,
                                    inference="none", advanced=False)
    focus = sorted({str(o).split("/")[-1] for o in
                    results.objects(None, URIRef("http://www.w3.org/ns/shacl#focusNode"))})
    if focus == ["r1", "r2", "r3"]:
        ok(f"語彙なし: 違反3件 {focus} "
           "(ex:r1 は正しい記述なのに違反になる。8.4 の注意ボックスのとおり)")
    else:
        fail(f"語彙なし: 期待 ['r1','r2','r3'] だが {focus}")

    # (b) RiC-O のクラス階層を一緒に渡した場合
    with_onto = Graph()
    with_onto += graphs["shacl-data.ttl"]
    for s, p, o in onto.triples((None, RDFS.subClassOf, None)):
        with_onto.add((s, p, o))
    conforms, results, _ = validate(with_onto, shacl_graph=shapes,
                                    inference="rdfs", advanced=False)
    focus = sorted({str(o).split("/")[-1] for o in
                    results.objects(None, URIRef("http://www.w3.org/ns/shacl#focusNode"))})
    if focus == ["r2", "r3"]:
        ok(f"語彙あり: 違反2件 {focus}(本文の記述と一致)")
    else:
        fail(f"語彙あり: 期待 ['r2','r3'] だが {focus}")

# ---------------------------------------------------------------------
# 6. 本文の listing とファイルの一致
#    本文に載っている Turtle が、examples/ の中身と食い違っていないか。
#    どちらかを直したときにもう一方を忘れる事故を防ぐための検査である。
# ---------------------------------------------------------------------
print("[6] 本文の listing との一致")

PRE = """
PREFIX rico:  <https://www.ica.org/standards/RiC/ontology#>
PREFIX rst:   <https://www.ica.org/standards/RiC/vocabularies/recordSetTypes#>
PREFIX ex:    <https://archives.example.jp/>
PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:   <http://www.w3.org/2002/07/owl#>
PREFIX skos:  <http://www.w3.org/2004/02/skos/core#>
PREFIX sh:    <http://www.w3.org/ns/shacl#>
PREFIX vocab: <https://archives.example.jp/vocab/>
PREFIX myo:   <https://archives.example.jp/ontology#>
"""

# 本文の listing を含む章 -> 照合先のグラフ。
# 「本文にあって examples/ にない実体」があれば報告する。ファイル側の
# 追加(接続や補助的な実体)は許す。
TRACKED = ["ch04.tex", "ch06.tex", "ch07.tex", "ch08.tex"]

union = Graph()
for name in DATA_FILES + ["shapes.ttl"]:
    union += graphs.get(name, Graph())
union_sp = {(s, p) for s, p, _ in union}
union_ground = {(s, p, o) for s, p, o in union if "N" != s.__class__.__name__[0]}

checked = missing = 0
for tex in (TRACKED if HAS_TEX else []):
    src = (REPO / tex).read_text()
    for block in re.findall(
            r"\\begin\{lstlisting\}\[language=turtle\](.*?)\\end\{lstlisting\}", src, re.S):
        if "GRAPH " in block or "rdfs:subPropertyOf" in block or "<_2020" in block:
            continue          # TriG 断片・オントロジー宣言・外部事例は対象外
        g = Graph()
        try:
            g.parse(data=PRE + block, format="turtle")
        except Exception:
            continue          # 構文の説明用の断片など
        ren = RENAMES.get(tex, {})

        def fix(node):
            if isinstance(node, URIRef) and str(node) in ren:
                return URIRef(ren[str(node)])
            return node

        subjects = {fix(s) for s in g.subjects() if isinstance(s, URIRef)}
        if not subjects & {s for s in union.subjects() if isinstance(s, URIRef)}:
            continue          # examples/ に対応がない例(山田家文書など)
        checked += 1
        for s, p, o in g:
            if not isinstance(s, URIRef):
                continue
            s, o = fix(s), fix(o)
            if s not in subjects:
                continue
            if isinstance(o, URIRef) or o.__class__.__name__ == "Literal":
                if (s, p, o) not in union and (s, p) not in union_sp:
                    fail(f"{tex}: 本文にあって examples/ にない --- "
                         f"{s.n3(union.namespace_manager)} "
                         f"{p.n3(union.namespace_manager)}")
                    missing += 1
            else:
                if (s, p) not in union_sp:
                    fail(f"{tex}: 本文にあって examples/ にない(空白ノード) --- "
                         f"{s.n3(union.namespace_manager)} "
                         f"{p.n3(union.namespace_manager)}")
                    missing += 1
if not HAS_TEX:
    print("  --  本書の .tex がないので飛ばす(配布 zip では対象外)")
elif missing == 0:
    ok(f"{checked} 個の listing について、主語述語の対がすべて examples/ にある")

# ---------------------------------------------------------------------
# 7. 本文の全 Turtle listing の構文と定義域・値域
#    [6] は examples/ に対応がある listing しか見ない。ここでは本文の
#    Turtle を章ごとにまとめてグラフにし、RiC-O の定義域・値域に照合する。
#    型が書かれていないノードは判定しない(断片なので当然そうなる)。
# ---------------------------------------------------------------------
print("[7] 本文の全 Turtle listing の照合")

# 意図的に誤りを含む listing、および対象外の listing を除く。
# 判定は listing 本文に含まれる文字列で行う。
SKIP_MARKERS = [
    "# 名称がない",              # 第8章 8.4 の検査対象データ(意図的に誤り)
    "GRAPH ",                    # TriG 断片
    "# (1) 全部を別の文で書く",  # 第5章 の記法の説明
    "rico:hasCreator ex:p1 .",   # 第5章 の省略記法の説明
    "<_2020",                    # 第5章 の docuteam の実データ例
]

if not HAS_TEX:
    print("  --  本書の .tex がないので飛ばす(配布 zip では対象外)")
elif len(onto):
    checked7 = parsed7 = problems7 = 0
    for tex in CHAPTERS:
        tblocks = re.findall(
            r"\\begin\{lstlisting\}\[language=turtle\](.*?)\\end\{lstlisting\}",
            tex.read_text(), re.S)
        merged = Graph()
        for block in tblocks:
            checked7 += 1
            if any(m in block for m in SKIP_MARKERS):
                continue
            g = Graph()
            try:
                g.parse(data=PRE + block, format="turtle")
            except Exception as e:
                fail(f"{tex.name}: Turtle として読めない listing がある --- {e}")
                continue
            parsed7 += 1
            merged += g
        if not len(merged):
            continue
        types7 = {}
        for s, o in merged.subject_objects(RDF.type):
            types7.setdefault(s, set()).add(o)

        def conforms7(node, allowed):
            if node not in types7:
                return None
            for t in types7[node]:
                if superclasses(onto, t) & allowed:
                    return True
            return False

        for s, p, o in merged:
            if not str(p).startswith(str(RICO)) or not isinstance(s, URIRef):
                continue
            if p in dom and conforms7(s, dom[p]) is False:
                fail(f"{tex.name}: 定義域違反 --- "
                     f"{s.n3(merged.namespace_manager)} "
                     f"{p.n3(merged.namespace_manager)} (許容: "
                     f"{sorted(c.split('#')[-1] for c in map(str, dom[p]))})")
                problems7 += 1
            if p in rng and isinstance(o, URIRef) and conforms7(o, rng[p]) is False:
                fail(f"{tex.name}: 値域違反 --- "
                     f"{p.n3(merged.namespace_manager)} -> "
                     f"{o.n3(merged.namespace_manager)} (許容: "
                     f"{sorted(c.split('#')[-1] for c in map(str, rng[p]))})")
                problems7 += 1
    if problems7 == 0:
        ok(f"本文の Turtle listing {checked7} 個(うち照合対象 {parsed7} 個)に "
           "定義域・値域の違反なし")

# ---------------------------------------------------------------------
# 8. 推論を入れたときの問い合わせの答え
#    RiC-O 本体を一緒に読み込んで OWL-RL の閉包を作り、「[推論]」と
#    注記した問い合わせが実際に答えを返すことを確かめる。owlrl がなければ
#    この検査だけ飛ばす(30秒ほどかかる)。
# ---------------------------------------------------------------------
print("[8] 推論を入れた問い合わせ")
try:
    import owlrl
except ImportError:
    print("  --  owlrl が入っていないので飛ばす(pip install owlrl)")
    owlrl = None

if owlrl is not None and len(onto):
    inf = Graph()
    for name in ["fonds-p83.ttl", "family.ttl", "disposition.ttl"]:
        inf += graphs.get(name, Graph())
    inf += onto
    owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(inf)
    for block in re.split(r"^### ", (HERE / "queries.rq").read_text(), flags=re.M)[1:]:
        head, _, body = block.partition("\n")
        num = int(re.match(r"(\d+)\.", head).group(1))
        exp = EXPECTED_ROWS_INFERRED.get(num)
        if exp is None:
            continue
        n = len(list(inf.query(body)))
        if n == exp:
            ok(f"問い合わせ {num}: 推論あり {n} 件 --- {head.strip()}")
        else:
            fail(f"問い合わせ {num}: 推論あり {n} 件(期待 {exp} 件)--- {head.strip()}")

# ---------------------------------------------------------------------
# 9. examples/ のコメントに手書きした節番号が、本書に実在するか
#    zip で配るので \ref が使えず、節を動かすとずれる。main.toc を読んで
#    照合する。ビルド後のリポジトリでだけ動く(配布 zip では飛ばす)。
#    なお「番号が実在するか」しか見ない。指し先の内容が合っているかは
#    人が読むほかないので、-v を付けると番号と見出しの対応を印字する。
# ---------------------------------------------------------------------
print()
print("[9] examples/ に手書きした節番号")
TOC = REPO / "main.toc"
if not TOC.exists():
    print("  --  main.toc がないので飛ばす(先に lualatex でビルドする)")
else:
    toc = {}
    for m in re.finditer(r"\\contentsline \{(?:sub)*section\}"
                         r"\{\\numberline \{([0-9A-Z.]+)\}(.*?)\}\{",
                         TOC.read_text(encoding="utf-8")):
        toc[m.group(1)] = re.sub(r"\\[a-zA-Z]+\s*", "", m.group(2))
    verbose = "-v" in sys.argv
    refs9 = problems9 = 0
    for path in sorted(HERE.iterdir()):
        if path.is_dir():
            continue
        try:
            lines = path.read_text(encoding="utf-8").split("\n")
        except (UnicodeDecodeError, IsADirectoryError):
            continue
        for ln, line in enumerate(lines, 1):
            # 「第6章 6.8.3」形式は章番号との一致も見る。「§6.2」「・6.8.3」は番号だけ。
            for m in re.finditer(r"第([0-9])章\s*([0-9]+\.[0-9]+(?:\.[0-9]+)?)", line):
                refs9 += 1
                ch, num = m.group(1), m.group(2)
                if num not in toc:
                    fail(f"{path.name}:{ln} 節 {num} は本書に存在しない")
                    problems9 += 1
                elif not num.startswith(ch + "."):
                    fail(f"{path.name}:{ln} 「第{ch}章 {num}」は章番号が合わない")
                    problems9 += 1
                elif verbose:
                    print(f"      {path.name}:{ln}  {num}  {toc[num]}")
            for m in re.finditer(r"[§・、]([0-9]+\.[0-9]+(?:\.[0-9]+)?)", line):
                refs9 += 1
                num = m.group(1)
                if num not in toc:
                    fail(f"{path.name}:{ln} 節 {num} は本書に存在しない")
                    problems9 += 1
                elif verbose:
                    print(f"      {path.name}:{ln}  {num}  {toc[num]}")
    if problems9 == 0:
        ok(f"{refs9} 件の節番号がすべて実在する(内容が合っているかは -v で目視)")

# ---------------------------------------------------------------------
print()
if fails:
    print(f"NG: {len(fails)} 件の問題")
    sys.exit(1)
print("すべて通った")
