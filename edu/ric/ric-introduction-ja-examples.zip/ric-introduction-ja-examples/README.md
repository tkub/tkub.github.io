# 動くサンプルデータ

『Records in Contexts 入門』の作例を、そのまま実行できるファイルにしたもの。
データはすべて架空である。本書と同じ CC BY 4.0 なので、授業や研修に自由に使える。

## ファイル

| ファイル | 中身 | 本書の該当箇所 |
|---|---|---|
| `fonds-p83.ttl` | 某県衛生部フォンド(P-83)一式。記録集合の階層、属性、出所関係の実体化、組織変遷、記述の記述 | 第4章 4.3.1・4.5、第6章 6.6、第7章 7.4・7.7.1 |
| `murakata.ttl` | 近世村方文書(宗門人別改帳)。ドメイン知識の3つの置き場所 | 第7章 7.5 |
| `family.ttl` | 山田家の系譜。共通の祖先をたどる推論の題材 | 第6章 6.7 |
| `disposition.ttl` | 保存期間・評価選別・廃棄・移管・デジタル化 | 第7章 7.9 |
| `queries.rq` | 本書に出てくる SPARQL 14件と、第6章 6.5 の近道の推論を確かめる1件 | 第6章 6.2・6.4〜6.8、第7章 7.7.1・7.9 |
| `shapes.ttl` | SHACL シェイプ | 第8章 8.4 |
| `shacl-data.ttl` | シェイプの検査対象。2箇所を意図的に誤らせてある | 第8章 8.4 |
| `check.py` | 下記の機械チェック | |

接頭辞は本書と同じ。`ex:` は `https://archives.example.jp/`、`rico:` は
`https://www.ica.org/standards/RiC/ontology#`。

配布 zip には `ric-o/` に RiC-O 1.1 の RDF と CSV 一覧を同梱してある。
ICA EGAD が CC BY 4.0 で公開しているものをそのまま入れた
(<https://github.com/ICA-EGAD/RiC-O>)。推論と検査に使う。

## 動かす

### rdflib

```sh
pip install rdflib pyshacl owlrl
```

問い合わせ3(活動を軸に組織変遷ごと一覧する)を走らせる例。

```sh
python3 -c "
from rdflib import Graph
import re
g = Graph()
for f in ('fonds-p83.ttl', 'family.ttl', 'disposition.ttl'):
    g.parse(f)
q = re.split(r'^### ', open('queries.rq').read(), flags=re.M)[3]
for row in g.query(q.split(chr(10), 1)[1]):
    print(row)
"
```

### Apache Jena Fuseki

```sh
python3 - <<'PYTHON'
from rdflib import Graph
g = Graph()
for name in ("fonds-p83.ttl", "murakata.ttl", "family.ttl", "disposition.ttl"):
    g.parse(name, format="turtle")
g.serialize(destination="all.ttl", format="turtle")
PYTHON
fuseki-server --file=all.ttl /ric
```

`http://localhost:3030/ric` の画面に `queries.rq` の問い合わせを貼りつける。
「[推論]」と注記した問い合わせ(1・12・13・15)は、RiC-O を一緒に読み込んで
推論を有効にしないと空を返す。

素の Fuseki は推論を行わない。RiC-O の定義を追加で読み込むだけでも、
推論は有効にならない。推論つきで試すなら、データと RiC-O を GraphDB の
OWL 2 RL リポジトリに読み込むか、`check.py` で結果を確認する。

### pySHACL

```sh
pyshacl -s shapes.ttl shacl-data.ttl
```

`ex:rec1` は正しい記述だが、これも違反として報告される。第8章 8.4 の注意
ボックスで説明した落とし穴である。RiC-O のクラス階層を一緒に渡すと、
報告は `ex:rec2` と `ex:rec3` の2件になる。

```sh
pyshacl -s shapes.ttl -e shacl-classes.ttl -i none shacl-data.ttl
```

`-i rdfs` にすると値域の推論が場所を Agent にも分類し、`rec3` の誤りを見逃す。ここでは事前推論を行わない。

## 機械チェック

```sh
python3 check.py
```

9項目を検査する。実行時間は環境による。

1. 全 `.ttl` が Turtle として妥当か
2. 使っている `rico:` 名が RiC-O 1.1 に実在するか
3. 使っているプロパティが定義域・値域に反していないか
4. `queries.rq` の全問い合わせが実行でき、期待した件数を返すか
5. SHACL が期待した違反だけを報告するか(語彙を渡す場合と渡さない場合)
6. 本文の Turtle listing と、ここのファイルが食い違っていないか
7. 本文の全 Turtle listing が構文として妥当で、定義域・値域に反していないか
8. 「[推論]」の問い合わせが、推論を入れたときに答えを返すか

6 と 7 は本書の `.tex` を読むので、リポジトリで実行したときだけ動く。
配布 zip では自動的に飛ばす(リポジトリで実行する場合は、`book-ric` の
ルートから `python3 examples/check.py`)。

8 は `owlrl` で RiC-O を含めた OWL-RL の閉包を作る。`owlrl` が入って
いなければこの項目だけ飛ばす。

## 本書との差分

ファイルは本書の断片をつなげたものなので、次の点で本文と違う。

- `ex:s2`(防疫統計系列)から `ex:series1950s` への `directlyIncludes` は、
  2つの章の断片をつなぐために足したもので、本文にはない。
- `family.ttl` の `ex:hanako`(山田花子)は、第5章の `ex:p1`(同名)とは
  別の実体にした。第5章と第6章は独立した例なので、そのまま分けている。
- `disposition.ttl` には、本文にない B-07(移管の例)と C-03(廃棄の定めは
  あるが内閣総理大臣の同意がまだ記述されていない例)を足した。問い合わせ
  9・10 が意味を持つようにするためである。
- 本文が紙幅の都合で省いている接頭辞宣言と型宣言(`rico:Instantiation` など)を、
  ファイルでは書いている。

`shacl-classes.ttl` は RiC-O 1.1 から抽出した名前付きクラスの上下関係であり、検査時に原典との一致も確認する。
