# 動くサンプルデータ

『Records in Contexts 入門』の作例を、そのまま実行できるファイルにしたもの。
データはすべて架空である。本書と同じ CC BY 4.0 なので、授業や研修に自由に使える。

## ファイル

| ファイル | 中身 | 本書の該当箇所 |
|---|---|---|
| `fonds-p83.ttl` | 某県衛生部フォンド(P-83)一式。記録集合の階層、属性、出所関係の実体化、組織変遷、記述の記述 | 第4章 4.3.1・4.5、第6章 6.6、第7章 7.4・7.7.2 |
| `murakata.ttl` | 近世村方文書(宗門人別改帳)。ドメイン知識の3つの置き場所 | 第7章 7.5 |
| `family.ttl` | 山田家の系譜。共通の祖先をたどる推論の題材 | 第6章 6.7 |
| `disposition.ttl` | 保存期間・評価選別・廃棄・移管・デジタル化 | 第7章 7.9 |
| `queries.rq` | 本書に出てくる SPARQL 14件 | 第6章 6.2・6.4・6.6・6.7・6.8、第7章 7.7.2・7.9 |
| `shapes.ttl` | SHACL シェイプ | 第8章 8.4 |
| `shacl-data.ttl` | シェイプの検査対象。2箇所を意図的に誤らせてある | 第8章 8.4 |
| `check.py` | 下記の機械チェック | |

接頭辞は本書と同じ。`ex:` は `https://archives.example.jp/`、`rico:` は
`https://www.ica.org/standards/RiC/ontology#`。

配布 zip には `ric-o/` に RiC-O 1.1 の RDF と CSV 一覧を同梱してある。
ICA EGAD が CC BY 4.0 で公開しているものをそのまま入れた
(<https://github.com/ICA-EGAD/RiC-O>)。推論と検査に使う。

## 動かす

### rdflib

```sh
pip install rdflib pyshacl owlrl
```

問い合わせ3(活動を軸に組織変遷ごと一覧する)を走らせる例。

```sh
python3 -c "
from rdflib import Graph
import re
g = Graph()
for f in ('fonds-p83.ttl', 'family.ttl', 'disposition.ttl'):
    g.parse(f)
q = re.split(r'^### ', open('queries.rq').read(), flags=re.M)[3]
for row in g.query(q.split(chr(10), 1)[1]):
    print(row)
"
```

### Apache Jena Fuseki

```sh
fuseki-server --file=fonds-p83.ttl --file=family.ttl --file=disposition.ttl /ric
```

`http://localhost:3030/ric` の画面に `queries.rq` の問い合わせを貼りつける。
「[推論]」と注記した問い合わせ(1・12・13)は、RiC-O を一緒に読み込んで
推論を有効にしないと空を返す。

```sh
fuseki-server --file=fonds-p83.ttl --file=family.ttl --file=disposition.ttl \
              --file=ric-o/RiC-O_1-1.rdf /ric
```

素の Fuseki は推論を行わない。推論つきで試すなら GraphDB(無償版)の
OWL2-RL または RDFS-Plus のリポジトリに読み込むほうが早い。

### pySHACL

```sh
pyshacl -s shapes.ttl shacl-data.ttl
```

`ex:r1` は正しい記述だが、これも違反として報告される。第8章 8.4 の注意
ボックスで説明した落とし穴である。RiC-O のクラス階層を一緒に渡すと、
報告は `ex:r2` と `ex:r3` の2件になる。

```sh
pyshacl -s shapes.ttl -e ric-o/RiC-O_1-1.rdf -i rdfs shacl-data.ttl
```

## 機械チェック

```sh
python3 check.py
```

8項目を検査する。所要12秒ほど。

1. 全 `.ttl` が Turtle として妥当か
2. 使っている `rico:` 名が RiC-O 1.1 に実在するか
3. 使っているプロパティが定義域・値域に反していないか
4. `queries.rq` の全問い合わせが実行でき、期待した件数を返すか
5. SHACL が期待した違反だけを報告するか(語彙を渡す場合と渡さない場合)
6. 本文の Turtle listing と、ここのファイルが食い違っていないか
7. 本文の全 Turtle listing が構文として妥当で、定義域・値域に反していないか
8. 「[推論]」の問い合わせが、推論を入れたときに答えを返すか

6 と 7 は本書の `.tex` を読むので、リポジトリで実行したときだけ動く。
配布 zip では自動的に飛ばす(リポジトリで実行する場合は、`book-ric` の
ルートから `python3 examples/check.py`)。

8 は `owlrl` で RiC-O を含めた OWL-RL の閉包を作る。`owlrl` が入って
いなければこの項目だけ飛ばす。

## 本書との差分

ファイルは本書の断片をつなげたものなので、次の点で本文と違う。

- 本文 §4.3.1 の `ex:s1` は、§7.4.2 の `ex:s1`(庶務系列)とは別物である。
  ファイルでは前者を `ex:series1950s` に改名し、第6章 6.6 の
  「伝染病予防関係綴」と同一の実体として扱った。
- `ex:s2`(防疫統計系列)から `ex:series1950s` への `directlyIncludes` は、
  2つの章の断片をつなぐために足したもので、本文にはない。
- `ex:series1950s` から `ex:r1` へは `includesOrIncluded`(本文 §4.3.1 の
  書き方)と `directlyIncludes` の両方を書いてある。`includesOrIncluded` は
  `includesTransitive` の上位プロパティなので、これだけでは §6.2 の推移閉包が
  記録まで届かない。narrower な `directlyIncludes` を足すと、問い合わせ1 が
  推論ありで答えを返すようになる。
- `family.ttl` の `ex:hanako`(山田花子)は、第5章の `ex:p1`(同名)とは
  別の実体にした。第5章と第6章は独立した例なので、そのまま分けている。
- `disposition.ttl` には、本文にない B-07(移管の例)と C-03(廃棄の定めは
  あるが内閣総理大臣の同意がまだ記述されていない例)を足した。問い合わせ
  9・10 が意味を持つようにするためである。
- 本文が紙幅の都合で省いている接頭辞宣言と型宣言(`rico:Instantiation` など)を、
  ファイルでは書いている。
