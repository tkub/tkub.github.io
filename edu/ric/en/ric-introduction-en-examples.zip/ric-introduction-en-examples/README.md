# Sample data for *Records in Contexts: An Introduction*

The examples from the book, in files you can load and run. Everything here
is fictional. Licensed CC BY 4.0, like the book itself, so it may be
adapted for teaching.

## What is here

| File | Contents | Chapters |
|---|---|---|
| `fonds-p83.ttl` | The Public Health Department fonds: hierarchy, attributes, provenance, a succession of organisations, the description record | 4, 6, 7 |
| `parish.ttl` | Parish records: the same fact written in each of the three places for domain knowledge | 7 (§7.5) |
| `family.ttl` | A line of descent, for the common-ancestor query | 6 (§6.7.2) |
| `disposition.ttl` | Retention, appraisal and disposal, and digitisation | 7 (§7.9) |
| `queries.rq` | The fourteen SPARQL queries from the book | 6, 7 |
| `shapes.ttl`, `shacl-data.ttl` | A SHACL shape and the data it validates | 8 (§8.4) |
| `check.py` | Mechanical checks over all of the above | |
| `ric-o/` | RiC-O 1.1 (RDF and the CSV lists), included so that inference and validation run without anything further | |

## Running the checks

```sh
pip install rdflib pyshacl owlrl
python3 check.py          # about 15 seconds
python3 check.py -v       # also prints each section number with its heading
```

Nine things are checked: that every `.ttl` parses; that every `rico:` name
used exists in RiC-O 1.1; that no property is used against its domain or
range; that every query runs and returns the expected number of rows; that
SHACL reports exactly the expected violations, with and without the
vocabulary; that the Turtle listings in the book agree with these files;
that every listing in the book parses and respects domains and ranges; that
the queries needing inference return answers once inference is on; and that
the section numbers written by hand in the comments exist in the book.

Three of them (the agreement with the listings, the check over every listing,
and the section numbers) read the sources of the book, so they are skipped
automatically when the archive is unpacked on its own.

## Running the queries yourself

With [Apache Jena Fuseki](https://jena.apache.org/):

```sh
fuseki-server --file=fonds-p83.ttl --file=family.ttl \
              --file=disposition.ttl /ric
```

Then paste a query from `queries.rq` into the web interface at
`http://localhost:3030/`. The queries marked `[inference]` return nothing
under Fuseki without a reasoner configured; that is the correct behaviour,
and it is what the book means when it says that inference has to be
switched on. To see them return answers, load the data into GraphDB with an
OWL 2 RL ruleset, or run `check.py`, which builds the closure with `owlrl`.

For SHACL:

```sh
pyshacl -s shapes.ttl -df turtle shacl-data.ttl
pyshacl -s shapes.ttl -e ric-o/RiC-O_1-1.rdf -df turtle shacl-data.ttl
```

The first reports three violations and the second two. The difference is
the trap described in the caution box of §8.4: without the RiC-O class
hierarchy, SHACL cannot tell that a Person is an Agent, and a correct
description fails.

## Where these files differ from the book

The book shows fragments; these files have to form a connected graph, so a
few triples are present here that the book does not print.

- `fonds-p83.ttl` uses both `includesOrIncluded` (as §4.3.1 writes it) and
  `directlyIncludes` on the series P-83/3, so that the property path in
  query 2 reaches the record.
- `disposition.ttl` holds two more files besides A-12: B-07, to be
  transferred rather than destroyed, and C-03, whose destruction has no
  consent recorded. Queries 9 and 10 exist to separate them.
- `parish.ttl` holds a second parish register, so that a search on the
  documentary form returns more than one row.
- `family.ttl` gives the great-grandfather two records and Margaret one (the
  field survey diary used throughout the book), so that the common-ancestor
  condition can be seen to drop hers.
