#!/usr/bin/env python3
"""Mechanical checks over the files in examples/.

There are nine checks. Numbers 6 and 7 read the .tex of the book and 9
reads main.toc, so those run only in the repository; in the distributed
archive they are skipped automatically.

  1. every .ttl parses as Turtle
  2. every rico: name used exists in RiC-O 1.1
  3. no property is used against its domain or range
  4. every query in queries.rq runs and returns the expected number of rows
  5. SHACL reports exactly the expected violations (with and without the vocabulary)
  6. the Turtle listings in the book agree with the files in examples/
  7. every Turtle listing in the book parses and respects domains and ranges
  8. the queries that need inference return answers once inference is on
  9. section numbers written by hand in comments exist in the book (-v prints headings)

Requires:
  pip install rdflib pyshacl owlrl

Reads the RDF and CSV of RiC-O 1.1, from sources/RiC-O/ in the repository
or from the bundled ric-o/ in the distributed archive.

Run:
  repository  python3 examples/check.py   (from the en/ directory)
  archive     python3 check.py            (in the unpacked directory)
"""

import csv
import re
import sys
from pathlib import Path

from rdflib import Graph, RDF, RDFS, OWL, URIRef
from rdflib.namespace import Namespace

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
RICO = Namespace("https://www.ica.org/standards/RiC/ontology#")

# Where RiC-O lives. Handles both the repository and the distributed archive.
SRC = next((d for d in (REPO / "sources" / "RiC-O",
                        REPO.parent / "sources" / "RiC-O",   # en/ inside book-ric
                        HERE / "ric-o")
            if (d / "RiC-O_1-1.rdf").exists()), REPO / "sources" / "RiC-O")

# Are the .tex files of the book here? If not, checks 6 and 7 are skipped.
CHAPTERS = sorted(REPO.glob("ch0*.tex"))
HAS_TEX = bool(CHAPTERS)
if HAS_TEX and (REPO / "appendix.tex").exists():
    CHAPTERS.append(REPO / "appendix.tex")

DATA_FILES = ["fonds-p83.ttl", "parish.ttl", "family.ttl",
              "disposition.ttl", "shacl-data.ttl"]

# Names the book uses in two senses, renamed on the file side. Empty because
# the English edition gives every thing one identifier (checks 6 and 9 would
# not catch a collision on their own, so keep it that way by hand).
RENAMES = {}

# Query number -> expected rows, running under plain rdflib without inference.
EXPECTED_ROWS = {
    1: 0,    # includesTransitive comes from inference
    2: 5,    # s1, s2, f112, cdpSeries, typhoidNotif
    3: 1,
    4: 2,    # Health and Welfare, Health and Social Care
    5: 5,
    6: 2,    # the letters (1868) and the diary (1885) of William Ellis
    7: 1,
    8: 1,
    9: 3,    # A-12 (destroy), B-07 (transfer), C-03 (destroy)
    10: 1,   # only the destruction of C-03 has no consent recorded
    11: 1,
    12: 0,   # hasOrHadInstantiation comes from subproperty inference
    13: 0,   # hasAncestor takes three steps of inference
    14: 2,   # the great-grandfather's letters and diary
}

# What the queries marked [inference] should return once inference is on.
# Fixing only the zero would not catch a query that had been broken.
EXPECTED_ROWS_INFERRED = {
    1: 1,    # a chain of directlyIncludes plus transitivity
    12: 2,   # the analogue and digital instantiations of ex:r45
    13: 2,   # inverse, subproperty and transitivity, three steps
}

fails = []


def fail(msg):
    fails.append(msg)
    print("  NG  " + msg)


def ok(msg):
    print("  ok  " + msg)


# ---------------------------------------------------------------------
# 1. Parsing the Turtle
# ---------------------------------------------------------------------
print("[1] Parsing the Turtle")
graphs = {}
for name in DATA_FILES + ["shapes.ttl", "shacl-classes.ttl"]:
    p = HERE / name
    g = Graph()
    try:
        g.parse(p, format="turtle")
        graphs[name] = g
        ok(f"{name}: {len(g)} triples")
    except Exception as e:
        fail(f"{name}: failed to parse: {e}")

# ---------------------------------------------------------------------
# 2. Do the rico: names exist?
# ---------------------------------------------------------------------
print("[2] Existence of rico: names (against the RiC-O 1.1 CSV lists)")
known = set()
for f in ["RiC-O_1-1_list-of-object-properties.csv",
          "RiC-O_1-1_list-of-datatype-properties.csv",
          "RiC-O_1-1_list-of-classes.csv"]:
    path = SRC / f
    if not path.exists():
        fail(f"{f} not found (looked in {SRC})")
        continue
    for row in csv.reader(open(path)):
        if row and row[0].startswith("rico:"):
            known.add(row[0][5:])
if known:
    for name in DATA_FILES + ["shapes.ttl", "queries.rq"]:
        used = set(re.findall(r"\brico:([A-Za-z0-9_]+)", (HERE / name).read_text()))
        unknown = sorted(used - known)
        if unknown:
            fail(f"{name}: names not in RiC-O: {unknown}")
        else:
            ok(f"{name}: all {len(used)} names exist")

# ---------------------------------------------------------------------
# 3. Domains and ranges
# ---------------------------------------------------------------------
print("[3] Domains and ranges (from the RDF itself, without inference)")
onto_path = SRC / "RiC-O_1-1.rdf"
onto = Graph()
if onto_path.exists():
    onto.parse(onto_path)
else:
    fail(f"{onto_path} not found")


def superclasses(g, cls, seen=None):
    seen = seen or set()
    if cls in seen:
        return seen
    seen.add(cls)
    for sup in g.objects(cls, RDFS.subClassOf):
        if isinstance(sup, URIRef):
            superclasses(g, sup, seen)
    return seen


if len(onto):
    # expand a union domain or range
    def class_list(g, node):
        if node is None:
            return set()
        if (node, OWL.unionOf, None) in g:
            out = set()
            for lst in g.objects(node, OWL.unionOf):
                out |= set(g.items(lst))
            return out
        return {node}

    dom, rng = {}, {}
    for p in set(onto.subjects(RDFS.domain, None)) | set(onto.subjects(RDFS.range, None)):
        d = set()
        for o in onto.objects(p, RDFS.domain):
            d |= class_list(onto, o)
        r = set()
        for o in onto.objects(p, RDFS.range):
            r |= class_list(onto, o)
        if d:
            dom[p] = d
        if r:
            rng[p] = r

    # shacl-data.ttl contains deliberate errors, so it is excluded here
    data = Graph()
    for name in ["fonds-p83.ttl", "parish.ttl", "family.ttl", "disposition.ttl"]:
        data += graphs.get(name, Graph())
    types = {}
    for s, o in data.subject_objects(RDF.type):
        types.setdefault(s, set()).add(o)

    def conforms(node, allowed):
        if node not in types:
            return None            # untyped nodes are not judged
        for t in types[node]:
            if superclasses(onto, t) & allowed:
                return True
        return False

    problems = 0
    for s, p, o in data:
        if not str(p).startswith(str(RICO)):
            continue
        if p in dom and conforms(s, dom[p]) is False:
            fail(f"domain violation: {s.n3(data.namespace_manager)} "
                 f"{p.n3(data.namespace_manager)} (allowed: "
                 f"{sorted(c.split('#')[-1] for c in map(str, dom[p]))})")
            problems += 1
        if p in rng and isinstance(o, URIRef) and conforms(o, rng[p]) is False:
            fail(f"range violation: {p.n3(data.namespace_manager)} -> "
                 f"{o.n3(data.namespace_manager)} (allowed: "
                 f"{sorted(c.split('#')[-1] for c in map(str, rng[p]))})")
            problems += 1
    if problems == 0:
        ok(f"no domain or range violations ({len(data)} triples checked)")

# ---------------------------------------------------------------------
# 4. queries.rq
# ---------------------------------------------------------------------
print("[4] Running queries.rq")
data = Graph()
for name in ["fonds-p83.ttl", "family.ttl", "disposition.ttl"]:
    data += graphs.get(name, Graph())

text = (HERE / "queries.rq").read_text()
blocks = re.split(r"^### ", text, flags=re.M)[1:]
for block in blocks:
    head, _, body = block.partition("\n")
    num = int(re.match(r"(\d+)\.", head).group(1))
    try:
        res = data.query(body)
        n = len(list(res))
    except Exception as e:
        fail(f"query {num} does not run: {e}")
        continue
    exp = EXPECTED_ROWS.get(num)
    if exp is None:
        ok(f"query {num}: {n} rows (no expectation set)")
    elif n == exp:
        ok(f"query {num}: {n} rows --- {head.strip()}")
    else:
        fail(f"query {num}: {n} rows (expected {exp}) --- {head.strip()}")

# ---------------------------------------------------------------------
# 5. SHACL
# ---------------------------------------------------------------------
print("[5] SHACL validation")
try:
    from pyshacl import validate
except ImportError:
    fail("pyshacl is not installed (pip install pyshacl)")
    validate = None

if validate is not None:
    shapes = graphs["shapes.ttl"]

    # (a) data alone: the trap described in the caution box of Chapter 8
    conforms, results, _ = validate(graphs["shacl-data.ttl"], shacl_graph=shapes,
                                    inference="none", advanced=False)
    focus = sorted({str(o).split("/")[-1] for o in
                    results.objects(None, URIRef("http://www.w3.org/ns/shacl#focusNode"))})
    if focus == ["rec1", "rec2", "rec3"]:
        ok(f"without the vocabulary: 3 violations {focus} "
           "(ex:rec1 is correct yet fails, exactly as the caution box in \u00a78.4 says)")
    else:
        fail(f"without the vocabulary: expected ['rec1','rec2','rec3'] but got {focus}")

    hierarchy = graphs["shacl-classes.ttl"]
    expected_hierarchy = {(s, p, o) for s, p, o in onto.triples((None, RDFS.subClassOf, None))
                          if isinstance(s, URIRef) and isinstance(o, URIRef)}
    if set(hierarchy) == expected_hierarchy:
        ok("SHACL class hierarchy matches RiC-O 1.1")
    else:
        fail("shacl-classes.ttl differs from the RiC-O named-class hierarchy")

    # (b) with the RiC-O class hierarchy loaded alongside
    conforms, results, _ = validate(graphs["shacl-data.ttl"], shacl_graph=shapes,
                                    ont_graph=hierarchy, inference="none", advanced=False)
    focus = sorted({str(o).split("/")[-1] for o in
                    results.objects(None, URIRef("http://www.w3.org/ns/shacl#focusNode"))})
    if focus == ["rec2", "rec3"]:
        ok(f"with the vocabulary: 2 violations {focus} (as the book says)")
    else:
        fail(f"with the vocabulary: expected ['rec2','rec3'] but got {focus}")

    # Range inference makes the Place an Agent and masks the creator error.
    full_graph = Graph()
    full_graph += graphs["shacl-data.ttl"]
    full_graph += onto
    _, inferred_results, _ = validate(full_graph, shacl_graph=shapes,
                                      inference="rdfs", advanced=False)
    inferred_focus = sorted({str(o).split("/")[-1] for o in
        inferred_results.objects(None, URIRef("http://www.w3.org/ns/shacl#focusNode"))})
    if inferred_focus == ["rec2"]:
        ok("RDFS range inference masks rec3, as the caution box explains")
    else:
        fail(f"RDFS inference: expected ['rec2'], got {inferred_focus}")

# ---------------------------------------------------------------------
# 6. Do the listings in the book agree with the files?
#    Guards against correcting one side and forgetting the other.
# ---------------------------------------------------------------------
print("[6] Agreement with the listings in the book")

PRE = """
PREFIX rico:  <https://www.ica.org/standards/RiC/ontology#>
PREFIX rst:   <https://www.ica.org/standards/RiC/vocabularies/recordSetTypes#>
PREFIX ex:    <https://archives.example.org/>
PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:   <http://www.w3.org/2002/07/owl#>
PREFIX skos:  <http://www.w3.org/2004/02/skos/core#>
PREFIX sh:    <http://www.w3.org/ns/shacl#>
PREFIX vocab: <https://archives.example.org/vocab/>
PREFIX myo:   <https://archives.example.org/ontology#>
"""

# Chapters with listings -> the graph to check against. Anything in the book
# but missing from examples/ is reported; additions on the file side
# (connections, auxiliary entities) are allowed.
TRACKED = ["ch04.tex", "ch06.tex", "ch07.tex", "ch08.tex"]

union = Graph()
for name in DATA_FILES + ["shapes.ttl", "shacl-classes.ttl"]:
    union += graphs.get(name, Graph())
union_sp = {(s, p) for s, p, _ in union}
union_ground = {(s, p, o) for s, p, o in union if "N" != s.__class__.__name__[0]}

checked = missing = 0
for tex in (TRACKED if HAS_TEX else []):
    src = (REPO / tex).read_text()
    for block in re.findall(
            r"\\begin\{lstlisting\}\[language=turtle\](.*?)\\end\{lstlisting\}", src, re.S):
        if ("GRAPH " in block or "rdfs:subPropertyOf" in block or "<_2020" in block
                or "derived by inference" in block):
            continue          # TriG fragments, ontology declarations, outside examples,
                              # and triples the reasoner adds rather than the files holding
        g = Graph()
        try:
            g.parse(data=PRE + block, format="turtle")
        except Exception:
            continue          # fragments illustrating syntax and the like
        ren = RENAMES.get(tex, {})

        def fix(node):
            if isinstance(node, URIRef) and str(node) in ren:
                return URIRef(ren[str(node)])
            return node

        subjects = {fix(s) for s in g.subjects() if isinstance(s, URIRef)}
        if not subjects & {s for s in union.subjects() if isinstance(s, URIRef)}:
            continue          # examples with no counterpart in examples/
        checked += 1
        for s, p, o in g:
            if not isinstance(s, URIRef):
                continue
            s, o = fix(s), fix(o)
            if s not in subjects:
                continue
            if isinstance(o, URIRef) or o.__class__.__name__ == "Literal":
                if (s, p, o) not in union and (s, p) not in union_sp:
                    fail(f"{tex}: in the book but not in examples/ --- "
                         f"{s.n3(union.namespace_manager)} "
                         f"{p.n3(union.namespace_manager)}")
                    missing += 1
            else:
                if (s, p) not in union_sp:
                    fail(f"{tex}: in the book but not in examples/ (blank node) --- "
                         f"{s.n3(union.namespace_manager)} "
                         f"{p.n3(union.namespace_manager)}")
                    missing += 1
if not HAS_TEX:
    print("  --  no .tex of the book here, so skipped (not run from the archive)")
elif missing == 0:
    ok(f"{checked} listings: every subject-predicate pair is present in examples/")

# ---------------------------------------------------------------------
# 7. Syntax, domains and ranges over every Turtle listing in the book
#    Check 6 sees only the listings with a counterpart in examples/. Here the
#    Turtle of each chapter is merged into a graph and checked against RiC-O.
#    Untyped nodes are not judged, since a listing is a fragment.
# ---------------------------------------------------------------------
print("[7] Every Turtle listing in the book")

# Exclude listings that contain deliberate errors, and those out of scope.
# Selection is by a string contained in the listing.
SKIP_MARKERS = [
    "# no name",                 # the SHACL test data of \u00a78.4 (deliberately wrong)
    "GRAPH ",                    # a TriG fragment
    "# (1) every statement",     # illustrating the notation, Chapter 5
    "rico:hasCreator ex:p1 .",   # illustrating abbreviation, Chapter 5
    "<_2020",                    # the docuteam sample data, Chapter 5
    "# derived by inference",    # triples the reasoner adds, not written in the files
]

if not HAS_TEX:
    print("  --  no .tex of the book here, so skipped (not run from the archive)")
elif len(onto):
    checked7 = parsed7 = problems7 = 0
    for tex in CHAPTERS:
        tblocks = re.findall(
            r"\\begin\{lstlisting\}\[language=turtle\](.*?)\\end\{lstlisting\}",
            tex.read_text(), re.S)
        merged = Graph()
        for block in tblocks:
            checked7 += 1
            if any(m in block for m in SKIP_MARKERS):
                continue
            g = Graph()
            try:
                g.parse(data=PRE + block, format="turtle")
            except Exception as e:
                fail(f"{tex.name}: a listing does not parse as Turtle --- {e}")
                continue
            parsed7 += 1
            merged += g
        if not len(merged):
            continue
        types7 = {}
        for s, o in merged.subject_objects(RDF.type):
            types7.setdefault(s, set()).add(o)

        def conforms7(node, allowed):
            if node not in types7:
                return None
            for t in types7[node]:
                if superclasses(onto, t) & allowed:
                    return True
            return False

        for s, p, o in merged:
            if not str(p).startswith(str(RICO)) or not isinstance(s, URIRef):
                continue
            if p in dom and conforms7(s, dom[p]) is False:
                fail(f"{tex.name}: domain violation --- "
                     f"{s.n3(merged.namespace_manager)} "
                     f"{p.n3(merged.namespace_manager)} (allowed: "
                     f"{sorted(c.split('#')[-1] for c in map(str, dom[p]))})")
                problems7 += 1
            if p in rng and isinstance(o, URIRef) and conforms7(o, rng[p]) is False:
                fail(f"{tex.name}: range violation --- "
                     f"{p.n3(merged.namespace_manager)} -> "
                     f"{o.n3(merged.namespace_manager)} (allowed: "
                     f"{sorted(c.split('#')[-1] for c in map(str, rng[p]))})")
                problems7 += 1
    if problems7 == 0:
        ok(f"{checked7} Turtle listings in the book ({parsed7} checked): "
           "no domain or range violations")

# ---------------------------------------------------------------------
# 8. What the queries return once inference is on
#    Load RiC-O alongside, build the OWL-RL closure, and confirm that the
#    queries marked [inference] do return answers. Skipped if owlrl is not
#    installed. Takes about 30 seconds.
# ---------------------------------------------------------------------
print("[8] Queries with inference")
try:
    import owlrl
except ImportError:
    print("  --  owlrl is not installed, so skipped (pip install owlrl)")
    owlrl = None

if owlrl is not None and len(onto):
    inf = Graph()
    for name in ["fonds-p83.ttl", "family.ttl", "disposition.ttl"]:
        inf += graphs.get(name, Graph())
    inf += onto
    owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(inf)
    # The common-ancestor chain also derives reverse and self pairs.
    ex = Namespace("https://archives.example.org/")
    common = URIRef("https://archives.example.org/ontology#hasCommonAncestorWith")
    for left, right in [(ex.margaret, ex.thomas), (ex.thomas, ex.margaret), (ex.margaret, ex.margaret)]:
        if (left, common, right) in inf:
            ok(f"common ancestor chain: {left} -> {right}")
        else:
            fail(f"common ancestor chain missing: {left} -> {right}")

    for block in re.split(r"^### ", (HERE / "queries.rq").read_text(), flags=re.M)[1:]:
        head, _, body = block.partition("\n")
        num = int(re.match(r"(\d+)\.", head).group(1))
        exp = EXPECTED_ROWS_INFERRED.get(num)
        if exp is None:
            continue
        n = len(list(inf.query(body)))
        if n == exp:
            ok(f"query {num}: {n} rows with inference --- {head.strip()}")
        else:
            fail(f"query {num}: {n} rows with inference (expected {exp}) --- {head.strip()}")

# ---------------------------------------------------------------------
# 9. Do the section numbers written by hand in the comments exist?
#    The files are distributed as an archive, so \ref is unavailable and the
#    numbers drift when a section moves. Checked against main.toc, so this
#    runs only in a built repository. It sees only whether a number exists;
#    whether it points at the right thing has to be read by a person, so -v
#    prints each number with its heading.
# ---------------------------------------------------------------------
print()
print("[9] Section numbers written by hand in examples/")
TOC = REPO / "main.toc"
if not TOC.exists():
    print("  --  no main.toc here, so skipped (build the book first)")
else:
    toc = {}
    for m in re.finditer(r"\\contentsline \{(?:sub)*section\}"
                         r"\{\\numberline \{([0-9A-Z.]+)\}(.*?)\}\{",
                         TOC.read_text(encoding="utf-8")):
        toc[m.group(1)] = re.sub(r"\\[a-zA-Z]+\s*", "", m.group(2))
    verbose = "-v" in sys.argv
    refs9 = problems9 = 0
    for path in sorted(HERE.iterdir()):
        if path.is_dir():
            continue
        try:
            lines = path.read_text(encoding="utf-8").split("\n")
        except (UnicodeDecodeError, IsADirectoryError):
            continue
        for ln, line in enumerate(lines, 1):
            # "Chapter 6, \u00a76.8.3" also has its chapter number checked; a bare "\u00a76.2" does not.
            for m in re.finditer(r"Chapter ([0-9]),\s*\u00a7([0-9]+\.[0-9]+(?:\.[0-9]+)?)", line):
                refs9 += 1
                ch, num = m.group(1), m.group(2)
                if num not in toc:
                    fail(f"{path.name}:{ln} section {num} does not exist in the book")
                    problems9 += 1
                elif not num.startswith(ch + "."):
                    fail(f"{path.name}:{ln} 'Chapter {ch}, {num}': the chapter number does not match")
                    problems9 += 1
                elif verbose:
                    print(f"      {path.name}:{ln}  {num}  {toc[num]}")
            for m in re.finditer(r"\u00a7([0-9]+\.[0-9]+(?:\.[0-9]+)?)", line):
                refs9 += 1
                num = m.group(1)
                if num not in toc:
                    fail(f"{path.name}:{ln} section {num} does not exist in the book")
                    problems9 += 1
                elif verbose:
                    print(f"      {path.name}:{ln}  {num}  {toc[num]}")
    if problems9 == 0:
        ok(f"all {refs9} section numbers exist (use -v to check the headings by eye)")

# ---------------------------------------------------------------------
print()
if fails:
    print(f"FAILED: {len(fails)} problem(s)")
    sys.exit(1)
print("all checks passed")
